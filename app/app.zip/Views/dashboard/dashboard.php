<?php $session = session(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-users"></i></span>

              <div class="info-box-content" style="font-size: 25px">
                <span class="info-box-text">Total Employee</span>
                <span class="info-box-number">
                  <?php if ($countAll) : ?>
                    <?php echo $countAll; ?>   
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-male"></i></span>

              <div class="info-box-content" style="font-size: 25px">
                <span class="info-box-text">Male</span>
                <span class="info-box-number">
                  <?php if ($countAll) : ?>
                    <?php echo $countMale; ?>   
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <div class="col-12 col-sm-6 col-md-2">
            <div class="info-box">
              <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-female"></i></span>

              <div class="info-box-content" style="font-size: 25px">
                <span class="info-box-text">Female</span>
                <span class="info-box-number">
                  <?php if ($countAll) : ?>
                    <?php echo $countFemale; ?>   
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

        </div>
        <!-- /.row -->


        <div class="row">
          <div class="col-12">
            <div class="card card-primary card-outline">
              <div class="card-header">
                <h3 class="card-title">Department Summary</h3>
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 600px;">
                <table class="table table-bordered table-head-fixed table-striped text-nowrap">
                  <thead style="text-align: center">
                    <tr style="line-height: 10px">
                      <th style="width:34%">Department</th>
                      <th style="width:34%">Head</th>
                      <th style="width:8%">Permanent</th>
                      <th style="width:8%">Casual</th>
                      <th style="width:8%">Job Order</th>
                      <th style="width:8%">Total</th>
                    </tr>
                  </thead>
                  <tbody  style="font-size:14px">
                    <?php if ($department) : ?>
                    <?php foreach ($department->getResult() as $post) : ?>
                      <tr style="line-height: 10px">
                        <td><?php echo strtoupper($post->department) ?></td>
                        <td><?php echo strtoupper($post->head) ?></td>
                        <td style="text-align: center">
                          <?php if ($permanent) : ?>
                            <?php foreach ($permanent->getResult() as $post2) : ?>
                              <?php if ($post2->dept_code == $post->dept_code) : ?>
                                <strong><?php echo $post2->permanent; ?></strong>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                          <?php if ($casual) : ?>
                            <?php foreach ($casual->getResult() as $post3) : ?>
                              <?php if ($post3->dept_code == $post->dept_code) : ?>
                                <strong><?php echo $post3->casual; ?></strong>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                          <?php if ($joborder) : ?>
                            <?php foreach ($joborder->getResult() as $post4) : ?>
                              <?php if ($post4->dept_code == $post->dept_code) : ?>
                                <strong><?php echo $post4->joborder; ?></strong>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                          <?php if ($alldept) : ?>
                            <?php foreach ($alldept->getResult() as $post5) : ?>
                              <?php if ($post5->dept_code== $post->dept_code) : ?>
                                <strong><?php echo $post5->allcount; ?></strong>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          <?php endif; ?>
                        </td>
                      </td> 
                      </tr>                     
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>