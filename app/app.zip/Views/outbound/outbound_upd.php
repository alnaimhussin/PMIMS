  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add New Outbound Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add New Outbound Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <?php
    $directory = FCPATH . '/public/assets/img/' . date('mdY');
    if (!file_exists($directory)) {
      mkdir($directory, 0777, TRUE);
    }
    ?>

    <?php $set = \Config\Services::session()->getFlashdata('validation'); ?>
    <?php $error = \Config\Services::session()->getFlashdata('error'); ?>
    <?php $txt = \Config\Services::validation()->listErrors(); ?>
    <div class="col-lg-6" <?php if ($set != "true") { echo "hidden"; $set = "false"; } ?>>
      <div class="card card-warning">
        <div class="card-header">
          <h3 class="card-title">Fields Required</h3>
          <!-- /.card-tools -->
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <?php echo $txt; ?>
          <?php echo $error; ?>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>
    <!-- Main content -->
    <section class="content">

<?= \Config\Services::validation()->listErrors(); ?>
      <!-- Default box -->
      <div class="card card-primary">
        <div class="card-header">
          <h3 class="card-title">Outbound Details</h3>
        </div>
        <?php if ($posts) : ?>
          <?php foreach ($posts->getResult() as $post) : ?>
        <form id="myForm" class="form-horizontal" method="post" enctype="multipart/form-data"
          onSubmit="return checkform()" action="<?= base_url() ?>/outbound/update">
          <div class="card-body">
            <div class="box-body">
              <div class="col-sm-12 col-lg-8">
                <input type="text" class="form-control" id="timestamp" name="timestamp"
                  value="<?php echo date("Y-m-d H:i:s"); ?>" placeholder="timestamp" hidden>
              </div>
              <div class="form-group row">
                <label for="lastname" class="col-sm-12 col-lg-2 col-form-label">Lastname</label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Lastname"
                    value="<?php if ($post) { echo strtoupper($post->lastname); } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="firstname" class="col-sm-12 col-lg-2 col-form-label">Firstname</label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname"
                    value="<?php if ($post) { echo strtoupper($post->firstname); } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="middlename" class="col-sm-12 col-lg-2 col-form-lcol-sm-12 col-lg-2abel">Middlename</label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middlename"
                    value="<?php if ($post) { echo strtoupper($post->middlename); } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="age" class="col-sm-12 col-lg-2 col-form-label">Age</label>
                <div class="col-sm-5 col-lg-2">
                  <input type="text" class="form-control" id="age" name="age" placeholder="Age"
                    value="<?php if ($post) { echo strtoupper($post->age); } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="birthday" class="col-sm-12 col-lg-2 col-form-label">Birthday</label>
                <div class="col-sm-5 col-lg-2">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                    </div>
                    <input type="text" class="form-control" id="birthday" name="birthday"
                      data-inputmask-alias="datetime" data-inputmask-inputformat="mm/dd/yyyy" data-mask
                      value="<?php if ($post) { echo strtoupper($post->birthday); } ?>">
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="gender" class="col-sm-12 col-lg-2 col-form-label">Gender</label>
                <div class="col-sm-5 col-lg-2">
                  <select class="form-control" id="gender" name="gender">
                    <option>Select Gender</option>
                    <option <?php if ($post) { if (strtoupper($post->gender) == "Male") { echo "selected"; } } ?>>Male</option>
                    <option <?php if ($post) { if (strtoupper($post->gender) == "Female") { echo "selected"; } } ?>>Female
                    </option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="mobile" class="col-sm-12 col-lg-2 col-form-label">Mobile #</label>
                <div class="col-sm-5 col-lg-2">
                  <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile"
                    data-inputmask='"mask": "9999-999-9999"' data-mask
                    value="<?php if ($post) { echo strtoupper($post->mobile); } ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="category" class="col-sm-12 col-lg-2 col-form-label">Category</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="category" name="category" onchange="disable(this.value)">
                    <option value="">Select Category</option>
                    <option value="1" <?php if ($post) { if (strtoupper($post->category) == "1") { echo "selected"; } } ?>>
                      LSI (Local Stranded Individual)</option>
                    <option value="2" <?php if ($post) { if (strtoupper($post->category) == "2") { echo "selected"; } } ?>>
                      Student</option>
                  </select>
                </div>
              </div>
              <div class="form-group row" id="requirements"
                <?php if (!$post) { echo "hidden"; } else { if (strtoupper($post->category) == "") { echo "hidden"; } } ?>>
                <label for="requirements" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Requirements</h3>
                    </div>
                    <div class="card-body">
                      <div class="form-group row">
                        <div class="col-sm-12 col-lg-5">
                          <div id="lsi"
                            <?php if (!$post) { echo "hidden"; } else { if (strtoupper($post->category) != "1") { echo "hidden"; } } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Medical Certificate (C/MHO) <br>
                                - Travel Authority (JTF Shield PNP) <br>
                                - Identification proof that you are a resident of Basilan
                              </div>
                            </div>
                          </div>
                          <div id="rof"
                            <?php if (!$post) { echo "hidden"; } else { if (strtoupper($post->category) != "2") { echo "hidden"; } } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Coordination with OWWA <br>
                                - Medical Certificate (C/MHO) <br>
                                - Travel Authority (JTF Shield PNP) <br>
                                - Identification proof that you are a resident of Basilan
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-12 col-lg-7">
                          <div class="input-group" id="medicalcert" <?php if ($post) {
                                                                      if (strtoupper($post->category) == "") {
                                                                        echo "hidden";
                                                                      }
                                                                    } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="medicalcert_image"
                                name="medicalcert_image" accept="image/png, image/jpeg, image/jpg, image/gif">
                              <label class="custom-file-label">Medical Certificate</label>
                            </div>
                          </div>
                          <div class="input-group" id="travelauth" style="margin-top:10px;" <?php if ($post) {
                                                                                              if (strtoupper($post->category) == "") {
                                                                                                echo "hidden";
                                                                                              }
                                                                                            } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="travelauth_image" name="travelauth_image"
                                accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">Travel Authority</label>
                            </div>
                          </div>
                          <div class="input-group" id="residency" style="margin-top:10px;" <?php if ($post) {
                                                                                              if (strtoupper($post->category) == "3") {
                                                                                                echo "hidden";
                                                                                              }
                                                                                            } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="residency_image" name="residency_image"
                                accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">Proof of Residency</label>
                            </div>
                          </div>
                          <div class="input-group" id="owwa" style="margin-top:10px;" <?php if ($post) {
                                                                                        if (strtoupper($post->category) != "2") {
                                                                                          echo "hidden";
                                                                                        }
                                                                                      } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="owwa_image" name="owwa_image"
                                accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">OWWA Coordination</label>
                            </div>
                          </div>
                          <div class="input-group" id="companyid" style="margin-top:10px;" <?php if ($post) {
                                                                                              if (strtoupper($post->category) != "3") {
                                                                                                echo "hidden";
                                                                                              }
                                                                                            } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="companyid_image" name="companyid_image"
                                accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">Company ID</label>
                            </div>
                          </div>
                          <div class="input-group" id="employmentcert" style="margin-top:10px;" <?php if ($post) {
                                                                                                  if (strtoupper($post->category) != "3") {
                                                                                                    echo "hidden";
                                                                                                  }
                                                                                                } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="employmentcert_image"
                                name="employmentcert_image" accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">Employment Certificate</label>
                            </div>
                          </div>
                          <div class="input-group" id="travelorder" style="margin-top:10px;" <?php if ($post) {
                                                                                                if (strtoupper($post->category) != "3") {
                                                                                                  echo "hidden";
                                                                                                }
                                                                                              } ?>>
                            <div class="custom-file">
                              <input type="file" class="custom-file-input" id="travelorder_image"
                                name="travelorder_image" accept="image/png, image/jpeg, image/gif">
                              <label class="custom-file-label">Company Travel Order</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
              <div class="form-group row">
                <label for="destination" class="col-sm-12 col-lg-2 col-form-label">Address in Basilan</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="lgu" name="lgu" onchange="getBarangay()">
                    <option value="">Select LGU</option>
                    <?php if ($lgu) : ?>
                    <?php foreach ($lgu->getResult() as $post2) : ?>
                    <option value="<?php echo $post2->lguCode; ?>"
                      <?php if ($post) { if (strtoupper($post->lgu) == $post2->lguCode) { echo "selected"; } } ?>>
                      <?php echo $post2->lguName; ?></option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="barangay" name="barangay">
                    <option value="<?php if ($post) {
                                      echo strtoupper($post->barangay);
                                    } else {
                                      echo "";
                                    } ?>">
                      <?php if ($post) {
                        echo strtoupper($post->barangay);
                      } else {
                        echo "Select Barangay";
                      } ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="address1" name="address1" placeholder="Address"
                    value="<?php if ($post) {
                                                                                                                        echo strtoupper($post->address1);
                                                                                                                      } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label">Address of Origin</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="province" name="province" onchange="getRefCityMun()">
                    <option value="">Select Province</option>
                    <?php if ($province) : ?>
                    <?php foreach ($province->getResult() as $post2) : ?>
                    <option value="<?php echo $post2->provCode; ?>"
                      <?php if ($post) { if (strtoupper($post->province) == $post2->provCode) { echo "selected"; } } ?>>
                      <?php echo $post2->provDesc; ?></option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="citymun" name="citymun">
                    <option value="<?php if ($post) { echo strtoupper($post->citymun); } else { echo ""; } ?>">
                      <?php if ($post) {
                        echo strtoupper($post->citymun);
                      } else {
                        echo "SELECT CITY / MUNICIPAL";
                      } ?>
                      </option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="address2" name="address2" placeholder="Address"
                    value="<?php if ($post) {
                                                                                                                        echo strtoupper($post->address2);
                                                                                                                      } ?>">
                </div>
              </div>
              <div class="form-group row">
                <label for="contactperson" class="col-sm-12 col-lg-2 col-form-label">Contact Person</label>
                <div class="col-sm-12 col-lg-3">
                  <input type="text" class="form-control" id="contactname" name="contactname" placeholder="Contact Name"
                    value="<?php if ($post) {
                                                                                                                                  echo strtoupper($post->contactname);
                                                                                                                                } ?>">
                </div>
                <div class="col-sm-6 col-lg-2">
                  <select class="form-control" id="contactrelation" name="contactrelation">
                    <option value="">Relationship</option>
                    <option value="Husband" <?php if ($post) {
                                              if (strtoupper($post->contactrelation) == "Husband") {
                                                echo "selected";
                                              }
                                            } ?>>Husband
                    </option>
                    <option value="Wife" <?php if ($post) {
                                            if (strtoupper($post->contactrelation) == "Wife") {
                                              echo "selected";
                                            }
                                          } ?>>Wife
                    </option>
                    <option value="Father" <?php if ($post) {
                                              if (strtoupper($post->contactrelation) == "Father") {
                                                echo "selected";
                                              }
                                            } ?>>Father
                    </option>
                    <option value="Mother" <?php if ($post) {
                                              if (strtoupper($post->contactrelation) == "Mother") {
                                                echo "selected";
                                              }
                                            } ?>>Mother
                    </option>
                    <option value="Brother" <?php if ($post) {
                                              if (strtoupper($post->contactrelation) == "Brother") {
                                                echo "selected";
                                              }
                                            } ?>>Brother
                    </option>
                    <option value="Sister" <?php if ($post) {
                                              if (strtoupper($post->contactrelation) == "Sister") {
                                                echo "selected";
                                              }
                                            } ?>>Sister
                    </option>
                    <option value="Son" <?php if ($post) {
                                          if (strtoupper($post->contactrelation) == "Son") {
                                            echo "selected";
                                          }
                                        } ?>>Son
                    </option>
                    <option value="Daughter" <?php if ($post) {
                                                if (strtoupper($post->contactrelation) == "Daughter") {
                                                  echo "selected";
                                                }
                                              } ?>>
                      Daughter</option>
                    <option value="Other" <?php if ($post) {
                                            if (strtoupper($post->contactrelation) == "Other") {
                                              echo "selected";
                                            }
                                          } ?>>Other
                    </option>
                  </select>
                </div>
                <div class="col-sm-6 col-lg-3">
                  <input type="text" class="form-control" id="contactnumber" name="contactnumber"
                    placeholder="Contact #" data-inputmask='"mask": "9999-999-9999"' data-mask
                    value=<?php if ($post) {
                                                                                                                                                                                      echo strtoupper($post->contactnumber);
                                                                                                                                                                                    } ?>>
                </div>
              </div>
              <div class="form-group row">
                <label for="transpo" class="col-sm-12 col-lg-2 col-form-label">With Vehicle</label>
                <div class="col-sm-12 col-lg-2">
                  <select class="form-control" id="withvehicle" name="withvehicle" onchange="enableInput()">
                    <option value="No"
                      <?php if ($post) { if (strtoupper($post->withvehicle) == "Yes") { echo "selected"; } } ?>>No</option>
                    <option value="Yes"
                      <?php if ($post) { if (strtoupper($post->withvehicle) == "No") { echo "selected"; } } ?>>
                      Yes</option>
                  </select>
                </div>
                <div class="col-sm-6 col-lg-2">
                  <input type="text" class="form-control" id="plate_no" name="plate_no"
                    value="<?php if ($post) { echo strtoupper($post->plate_no); } ?>" placeholder="Plate Number"
                    <?php if (!$post) { echo "hidden"; } else { if (strtoupper($post->withvehicle) != "land") { echo " hidden"; } } ?>>
                </div>
                <div class="col-sm-6 col-lg-4">
                  <input type="text" class="form-control" id="vehicle_color_made" name="vehicle_color_made"
                    value="<?php if ($post) { echo strtoupper($post->vehicle_color_made); } ?>"
                    placeholder="Vehicle Color / Made"
                    <?php if (!$post) { echo "hidden"; } else { if (strtoupper($post->withvehicle) != "land") { echo " hidden"; } } ?>>
                </div>
              </div>
              <div class="form-group row">
                <label for="departure" class="col-sm-12 col-lg-2 col-form-label">Departure</label>
                <div class="col-sm-12 col-lg-2">
                  <div class="input-group" id="depart">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control" id="departure" name="departure"
                      value="<?php if ($post) { echo strtoupper($post->departure); } ?>" placeholder="Date of Departure"
                      data-inputmask-alias="datetime" data-inputmask-inputformat="mm/dd/yyyy" data-mask>
                  </div>
                </div>
              </div>
            </div>

          </div>
      </div>
      <div class="card-footer">
        <div class="box-footer">
          <div class="col-lg-4" style=" margin-left: auto; margin-right: auto">
            <button type="submit" class="btn btn-success btn-block btn-flat"
              style="height: 50px; font-size: 20px">Submit</button>
          </div>
        </div>
      </div>
            <?php endforeach; ?>
          <?php endif; ?>
      </form>
  </div>
  </section>
  </div>

  <script>
    function checkform() {
      var transpo = $('#transportation').val();
      var airline = $('#airline').val();
      var ref_air = $('#ref_air').val();
      var sea_vessel = $('#sea_vessel').val();
      var ref_sea = $('#ref_sea').val();
      var plate_no = $('#plate_no').val();
      var vehicle_color_made = $('#vehicle_color_made').val();
      var departure = $('#departure').val();
      var plate_no = $('#plate_no').val();

      if (transpo == "air") {
        if (airline == "") {
          alert('Please select airline.');
          return false;
        }
        if (ref_air == "") {
          alert('Please enter airline reference #.');
          return false;
        }
        if (departure == "") {
          alert('Please enter departure date.');
          return false;
        }
      } else if (transpo == "sea") {
        if (sea_vessel == "") {
          alert('Please select sea vessel.');
          return false;
        }
        if (ref_sea == "") {
          alert('Please enter sea vessel reference #.');
          return false;
        }
        if (departure == "") {
          alert('Please enter departure date.');
          return false;
        }
      } else if (transpo == "land") {
        if (plate_no == "") {
          alert('Please enter plate number.');
          return false;
        }
        if (vehicle_color_made == "") {
          alert('Please enter color and made of vehicle.');
          return false;
        }
        if (departure == "") {
          alert('Please enter departure date.');
          return false;
        }
      }
      return true;
    }

    function getRefCityMun() {
      var provCode = $('#province').val();
      if (provCode) {
        $.ajax({
          url: '<?php echo base_url(); ?>/dynamic/fetch_citymun/' + provCode,
          method: "POST",
          data: {
            provCode: provCode
          },
          async: true,
          dataType: 'json',
          success: function (data) {
            var html = '';
            var i;
            html += '<option value="">SELECT CITY / MUNICIPAL</option>';
            for (i = 0; i < data.length; i++) {
              html += '<option value=' + data[i].citymunDesc + '>' + data[i].citymunDesc.toUpperCase() +
                '</option>';
            }
            $('#citymun').html(html);

          }
        });
        return false;
      }
    }

    function getBarangay(id) {
      var lgu = $('#lgu').val();
      if (lgu) {
        $.ajax({
          url: '<?php echo base_url(); ?>/dynamic/fetch_barangay/' + lgu,
          method: "POST",
          data: {
            lgu: lgu
          },
          async: true,
          dataType: 'json',
          success: function (data) {

            var html = '';
            var i;
            html += '<option>SELECT BARANGAY</option>';
            for (i = 0; i < data.length; i++) {
              html += '<option value=' + data[i].brgyName + '>' + data[i].brgyName.toUpperCase() + '</option>';
            }
            $('#barangay').html(html);

          }
        });
        return false;
      }
    }

    function disable(id) {
      var lsi = document.getElementById('lsi');
      var rof = document.getElementById('rof');
      var apor = document.getElementById('apor');

      var requirements = document.getElementById('requirements');
      var owwa = document.getElementById('owwa');
      var medicalcert = document.getElementById('medicalcert');
      var travelauth = document.getElementById('travelauth');
      var residency = document.getElementById('residency');
      var companyid = document.getElementById('companyid');
      var employmentcert = document.getElementById('employmentcert');
      var travelorder = document.getElementById('travelorder');

      if (id == '1') {
        requirements.hidden = false;
        lsi.hidden = false;
        rof.hidden = true;
        apor.hidden = true;

        owwa.hidden = true;
        medicalcert.hidden = false;
        travelauth.hidden = false;
        residency.hidden = false;
        companyid.hidden = true;
        employmentcert.hidden = true;
        travelorder.hidden = true;
      } else if (id == '2') {
        requirements.hidden = false;
        lsi.hidden = true;
        rof.hidden = false;
        apor.hidden = true;

        owwa.hidden = false;
        medicalcert.hidden = false;
        travelauth.hidden = false;
        residency.hidden = false;
        companyid.hidden = true;
        employmentcert.hidden = true;
        travelorder.hidden = true;
      } else if (id == '3') {
        requirements.hidden = false;
        lsi.hidden = true;
        rof.hidden = true;
        apor.hidden = false;

        owwa.hidden = true;
        medicalcert.hidden = false;
        travelauth.hidden = false;
        residency.hidden = true;
        companyid.hidden = false;
        employmentcert.hidden = false;
        travelorder.hidden = false;
      } else {
        requirements.hidden = true;
        lsi.hidden = true;
        rof.hidden = true;
        apor.hidden = true;

        owwa.hidden = true;
        medicalcert.hidden = true;
        travelauth.hidden = true;
        residency.hidden = true;
        companyid.hidden = true;
        employmentcert.hidden = true;
        travelorder.hidden = true;
      }
    }

    function enableInput() {
      var transpo = document.getElementById("withvehicle").value;
      var plate_no = document.getElementById("plate_no");
      var vehicle_color_made = document.getElementById("vehicle_color_made");
      if (transpo == "Yes") {
        plate_no.hidden = false;
        plate_no.value = "";
        vehicle_color_made.hidden = false;
        vehicle_color_made.value = "";
      } else if (transpo == "No") {
        plate_no.hidden = true;
        plate_no.value = "";
        vehicle_color_made.hidden = true;
        vehicle_color_made.value = "";
      }
    }
  </script>