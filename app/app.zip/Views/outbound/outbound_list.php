  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Outbound List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Outbound List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">List of all Outbounds</h3>
              </div>
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Action</th>
                      <th>Name</th>
                      <th>Mobile #</th>
                      <th>Category</th>
                      <th>Origin</th>
                      <th>Destination</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1;
                    if ($posts) : ?>
                    <?php foreach ($posts->getResult() as $post) : ?>
                    <?php if ($post->category == 1) { $category = "LSI"; } else if ($post->category == 2) { $category = "STUDENT"; } ?>
                    <tr>
                      <td><?php echo $i ?></td>
                      <td>
                        <button class="btn bg-danger" onclick="callme(<?php echo strtoupper($post->_id) ?>)"><i
                            class="fa fa-trash"></i></button>
                        <a class="btn bg-warning"
                          href="<?= base_url() ?>/outbound/view/<?php echo strtoupper($post->_id) ?>"><i
                            class="fa fa-eye"></i></a>
                      </td>
                      <td><?php echo strtoupper($post->lastname.', '.$post->firstname.' '.$post->middlename) ?></td>
                      <td><?php echo strtoupper($post->mobile) ?></td>
                      <td><?php echo strtoupper($category) ?></td>
                      <td><?php echo strtoupper($post->provDesc). ", " .strtoupper($post->citymun) ?></td>
                      <td><?php echo strtoupper($post->lguName). ", " .strtoupper($post->barangay);$i++; ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>