  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Events</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Events</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fas fa-glass-cheers"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Function Room Available</span>
                <span class="info-box-number">
                  10
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-glass-cheers"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Active Event</span>
                <span class="info-box-number">
                  10
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fas fa-bookmark"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Reservation</span>
                <span class="info-box-number">4</span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

        </div>

        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-lg" style="width: 200px; margin-bottom: 15px">Book Event</button>
        <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal-lg" style="width: 200px; margin-bottom: 15px">Move Event</button>
        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-lg" style="width: 200px; margin-bottom: 15px">Cancel Event</button>

        <!-- /.row -->
        <div class="row">
          <div class="col-7">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Function Room List</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: auto; width: auto">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Room #</th>
                      <th>Status</th>
                      <th>Start</th>
                      <th>End</th>
                      <th>Name</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-success">Available</span></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td><span class="badge bg-danger">Occupied</span></td>
                      <td>6-3-2021</td>
                      <td>6-5-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <div class="col-5">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Incoming Event</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: auto; width: auto">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Room</th>
                      <th>Date</th>
                      <th>Name</th>
                      <th>Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>183</td>
                      <td>6-3-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td>6-3-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td>6-3-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td>6-3-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                    <tr>
                      <td>183</td>
                      <td>6-3-2021</td>
                      <td>Naim S. Hussin</td>
                      <td>Bacon ipsum dolor sit amet salami.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
  </div>