  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inbound List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Inbound List</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">List of all Inbounds</h3>
              </div>
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Action</th>
                      <th>Documents</th>
                      <th>Name</th>
                      <th>Mobile #</th>
                      <th>Category</th>
                      <th>Origin</th>
                      <th>Destination</th>
                      <th>Departure</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1;
                    if ($posts) : ?>
                    <?php foreach ($posts->getResult() as $post) : ?>
                    <?php if ($post->category == 1) { $category = "LSI"; } else if ($post->category == 2) { $category = "ROF"; } else if ($post->category == 3) { $category = "APOR"; } ?>
                    <tr>
                      <td><?php echo $i ?></td>
                      <td>
                        <button class="btn bg-danger" onclick="callme(<?php echo strtoupper($post->_id) ?>)"><i
                            class="fa fa-trash"></i></button>
                        <a class="btn bg-warning"
                          href="<?= base_url() ?>/inbound/view/<?php echo strtoupper($post->_id) ?>"><i
                            class="fa fa-eye"></i></a>
                      </td>
                      <td class="<?php if ($post->isValidated != "") { echo "bg-success"; } ?>"><?php if ($post->isValidated != "") { echo "VALIDATED"; } ?></td>
                      <td><?php echo strtoupper($post->lastname.', '.$post->firstname.' '.$post->middlename) ?></td>
                      <td><?php echo strtoupper($post->mobile) ?></td>
                      <td><?php echo strtoupper($category) ?></td>
                      <td><?php echo strtoupper($post->provDesc). ", " .strtoupper($post->citymun) ?></td>
                      <td><?php echo strtoupper($post->lguName). ", " .strtoupper($post->barangay);$i++; ?></td>
                      <td><?php echo strtoupper($post->departure) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </tbody>
                  <tfoot>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>

  <script>
    function callme(id) {
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.value) {
          $.ajax({
            url: '<?php echo base_url(); ?>/Inbound/delete/' + id,
            method: "POST",
            async: true,
            dataType: 'json',
          });
          Swal.fire({
            title: 'Deleted!',
            text: "Your file has been deleted.",
            icon: 'success',
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ok'
          }).then((result) => {
            window.location.href = "<?php echo base_url().'/inbound/list'; ?>";
          })
          // return false;
        }
      })
    }
  </script>