  <!-- Content Wrapper. Contains page content -->
  <style>
    page {
      background: white;
      display: block;
      margin: 0 auto;
      margin-bottom: 0.5cm;
      box-shadow: 0 0 0.5cm rgba(0, 0, 0, 0.5);
    }

    page[size="A4"] {
      width: 21cm;
      height: 29.7cm;
    }

    .printThis {
	  display: none;
    }

    @media print {

      body,
      page {
        font-size: 13px;
        margin: 0;
        box-shadow: 0;
      }

      .printThis  {
        display: block;
      }

      .graph-img img {
        display: inline;
      }
    }
  </style>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Travel Pass Details</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <?php $session = \Config\Services::session(); ?>    

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card card-primary">
        <div class="card-header">
          <h3 class="card-title">Travel Pass Details</h3>
        </div>
        <?php if ($posts) : ?>
        <?php foreach ($posts->getResult() as $post) : ?>
        <form id="myForm" class="form-horizontal" method="post" enctype="multipart/form-data">
          <div class="card-body">
            <div class="box-body">
            
              <div class="col-sm-12 col-lg-8">
                <input type="text" class="form-control" id="timestamp" name="timestamp"
                  value="<?php echo date("Y-m-d H:i:s"); ?>" placeholder="timestamp" hidden>
              </div>
              <div class="form-group row">
                <label for="category" class="col-sm-12 col-lg-2 col-form-label">Category</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="category" name="category" disabled>
                    <option value="">Select Category</option>
                    <option value="1" <?php if ($post->category == "1") { echo "selected"; } ?>>
                      MEDICAL FRONTLINER</option>
                    <option value="2" <?php if ($post->category == "2") { echo "selected"; } ?>>
                      ESSENTIAL / APOR / GOV'T EMPLOYEE / PUBLIC SERVANT</option>
                    <option value="3" <?php if ($post->category =="3") { echo "selected"; } ?>>
                      BUSINESS PURPOSE</option>
                    <option value="4" <?php if ($post->category =="4") { echo "selected"; } ?>>
                      PATIENT & WATCHER</option>
                  </select>
                </div>
              </div>

              <?php
              if($post->category == "1") { 
                $doc = "Frontliner ID <br>Medical Certificate (C/MHO)";
              }
              if ($post->category == "2") { 
                $doc = "Government ID <br>Medical Certificate (C/MHO) <br>Chest X-Ray Result <br>Travel Order";
              }
              if ($post->category == "3") {
                $doc = "Business Permit <br>Medical Certificate (C/MHO) <br>Chest X-Ray Result <br>Vehicle / Truck papers";
              }
              if ($post->category == "4") { 
                $doc = "Referral or Appointment Letter <br>Medical Certificate (C/MHO) <br>Chest X-Ray Result <br>&nbsp;&nbsp;&nbsp;(if emergency no x-ray needed)";} 
              ?>

              <div class="form-group row" id="requirements">
                <label for="requirements" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Requirements</h3>
                    </div>
                    <div class="card-body">
                      <div class="form-group row">
                        <div class="col-sm-12 col-lg-5">
                          <div id="fr" <?php if ($post->category != "1") { echo "hidden"; } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Frontliner ID <br>
                                - Medical Certificate (C/MHO)
                              </div>
                            </div>
                          </div>
                          <div id="govt" <?php if ($post->category != "2") { echo "hidden"; } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Government ID <br>
                                - Medical Certificate (C/MHO) <br>
                                - Chest X-Ray Result <br>
                                - Travel Order
                              </div>
                            </div>
                          </div>
                          <div id="business" <?php if ($post->category != "3") { echo "hidden"; } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Business Permit <br>
                                - Medical Certificate (C/MHO) <br>
                                - Chest X-Ray Result <br>
                                - Vehicle / Truck papers
                              </div>
                            </div>
                          </div>
                          <div id="patient" <?php if ($post->category != "4") { echo "hidden"; } ?>>
                            <div class="card card-primary">
                              <div class="card-body">
                                - Referral or Appointment Letter <br>
                                - Medical Certificate (C/MHO) <br>
                                - Chest X-Ray Result <br>
                                &nbsp;&nbsp;&nbsp;(if emergency no x-ray needed)
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label">Purpose</label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="purpose" name="purpose" placeholder="Purpose of travel"
                    value="<?php if ($posts) { echo $post->purpose; } ?>" disabled>
                </div>
              </div>
              <div class="form-group row">
                <label for="destination" class="col-sm-12 col-lg-2 col-form-label">Address in Basilan</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="lgu" name="lgu" onchange="getBarangay()" disabled>
                    <option value="">Select LGU</option>
                    <?php if ($lgu) : ?>
                    <?php foreach ($lgu->getResult() as $lgu) : ?>
                    <option value="<?php echo $lgu->lguCode; ?>"
                      <?php if ($post->lgu == $lgu->lguCode) { echo "selected"; $lgu_name = $lgu->lguName; } ?>>
                      <?php echo $lgu->lguName; ?></option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="barangay" name="barangay" disabled>
                    <option value="<?php if ($post->barangay) { echo $post->barangay; } else { echo ""; } ?>">
                      <?php if ($post->barangay) { echo $post->barangay; } else { echo "Select Barangay"; } ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="address1" name="address1" placeholder="Address"
                    value="<?php if ($post) { echo $post->address1; } ?>" disabled>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label">Address of Destination</label>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="province" name="province" onchange="getRefCityMun()" disabled>
                    <option value="">Select Province</option>
                    <?php if ($province) : ?>
                    <?php foreach ($province->getResult() as $prov) : ?>
                    <option value="<?php echo $prov->provCode; ?>"
                      <?php if ($post) { if ($post->province == $prov->provCode) { echo "selected"; $prov_name = $prov->provDesc; } } ?>>
                      <?php echo $prov->provDesc; ?></option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-12 col-lg-4">
                  <select class="form-control" id="citymun" name="citymun" disabled>
                    <option value="<?php if ($post) { echo $post->citymun; } else { echo ""; } ?>">
                      <?php if ($post) { echo $post->citymun; } else { echo "Select City / Municipal"; } ?></option>
                  </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="origins" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-sm-12 col-lg-8">
                  <input type="text" class="form-control" id="address2" name="address2" placeholder="Address"
                    value="<?php if ($post) { echo $post->address2; } ?>" disabled>
                </div>
              </div>

              <div class="form-group row">
                <label for="transpo" class="col-sm-12 col-lg-2 col-form-label">With Vehicle</label>
                <div class="col-sm-12 col-lg-2">
                  <select class="form-control" id="withvehicle" name="withvehicle" onchange="enableInput()" disabled>
                    <option value="No" <?php if ($post) { if ($post->withvehicle == "Yes") { echo "selected"; } } ?>>No
                    </option>
                    <option value="Yes" <?php if ($post) { if ($post->withvehicle == "No") { echo "selected"; } } ?>>
                      Yes</option>
                  </select>
                </div>
                <div class="col-sm-6 col-lg-2">
                  <input type="text" class="form-control" id="plate_no" name="plate_no"
                    value="<?php if ($post) { echo $post->plate_no; } ?>" placeholder="Plate Number"
                    <?php if (!$post) { echo "hidden"; } else { if ($post->withvehicle != "land") { echo " hidden"; } } ?>
                    disabled>
                </div>
                <div class="col-sm-6 col-lg-4">
                  <input type="text" class="form-control" id="vehicle_color_made" name="vehicle_color_made"
                    value="<?php if ($post) { echo $post->vehicle_color_made; } ?>" placeholder="Vehicle Color / Made"
                    <?php if (!$post) { echo "hidden"; } else { if ($post->withvehicle != "land") { echo " hidden"; } } ?>
                    disabled>
                </div>
              </div>
              <div class="form-group row">
                <label for="departure" class="col-sm-12 col-lg-2 col-form-label">Departure</label>
                <div class="col-sm-12 col-lg-2">
                  <div class="input-group" id="depart">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control" id="departure" name="departure"
                      value="<?php if ($post) { echo $post->departure; } ?>" placeholder="Date of Departure"
                      data-inputmask-alias="datetime" data-inputmask-inputformat="mm/dd/yyyy" data-mask disabled>
                  </div>
                </div>
              </div>
              <div class="form-group row">
                <label for="departure" class="col-sm-12 col-lg-2 col-form-label">Departure</label>
                <div class="col-sm-12 col-lg-2">
                  <div class="input-group" id="depart">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                    <input type="text" class="form-control" id="returndate" name="returndate"
                      value="<?php if ($post) { echo $post->returndate; } ?>" placeholder="Return"
                      data-inputmask-alias="datetime" data-inputmask-inputformat="mm/dd/yyyy" data-mask disabled>
                  </div>
                </div>
              </div>

              <div class="form-group row">
                <label class="col-sm-12 col-lg-2 col-form-label">Member</label>
                <div class="col-sm-12 col-lg-8">
                  <table id="member_table" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th style="width:5%">#</th>
                        <th style="width:50%">Name</th>
                        <th style="width:20%">Gender</th>
                        <th style="width:25%">Mobile #</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $i = 1; $data = "Name/s:" . "\r\n";
                      if ($posts_2) : ?>
                      <?php foreach ($posts_2->getResult() as $table) : ?>
                      <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo strtoupper($table->lastname.', '.$table->firstname.' '.$table->middlename) ?></td>
                        <td><?php echo strtoupper($table->gender) ?></td>
                        <td><?php echo strtoupper($table->mobile); $i++; ?></td>
                        
                        <?php $data = $data . strtoupper($table->lastname.', '.$table->firstname.' '.$table->middlename) . "\r\n"; ?>
                        
                      </tr>
                      <?php endforeach; ?>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>

              <div class="form-group row">
                <label for="lastname" class="col-sm-12 col-lg-2 col-form-label"></label>
                <div class="col-lg-2" style="margin-right: auto">
                  <button type="button" onclick="validate(<?php if ($post) { echo $post->pass_id; } ?>)"
                    class="btn btn-success btn-block btn-flat" <?php if ($post) { if ($post->status == "validated") { echo "disabled"; }  } ?>>Approved</button>
                  <button type="button" class="btn btn-primary btn-block btn-flat" data-toggle="modal"
                    data-target="#travelpass" <?php if ($post) { if ($post->status != "validated") { echo "disabled"; }  } ?>>Travel Pass</button>
                </div>
              </div>

            </div>
          </div>
        </form>

        <?php
        
        $input1 = $post->departure; 
        $date1 = strtotime($input1); 
        $date_depart = date('F d, Y', $date1); 

        if ($post->category == 1) { $category = "MEDICAL FRONTLINER";
          } else if ($post->category == 2) { $category = "ESSENTIAL / APOR / GOV'T EMPLOYEE / PUBLIC SERVANT";
          } else if ($post->category == 3) { $category = "BUSINESS PURPOSE";
          } else ($post->category == 3) { $category = "PATIENT & WATCHER" } ?>
          
        <?php $data = $data . "\r\nTravel Pass Type: " . $category; ?>
        <?php $data = $data . "\r\nDestination: " . $post->citymun . ", " . $prov_name; ?>
        <?php $data = $data . "\r\nDeparture Date: " . $date_depart; ?>

        <?php endforeach; ?>
        <?php endif; ?>
      </div>

    </section>
    <?php    

    // $pass_id = $post->pass_id;
    $pass_id = $data;
 
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';
    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    $filename = $PNG_TEMP_DIR.'qr.png';    
    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'H';
    $matrixPointSize = 10;

    if (isset($post->pass_id)) { 
        //it's very important!
        if (trim($pass_id) == '')
            die('data cannot be empty!');            
        // user data
        $filename = $PNG_TEMP_DIR.'qr'.md5($pass_id.'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
        QRcode::png($pass_id, $filename, $errorCorrectionLevel, $matrixPointSize, 2);   
        
    } else {        
        //default data
        QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);            
    }            
    //display generated file
    $source = 'app/Views/travelpass/temp/'.basename($filename);
    $destination = 'img/travelpassqr/'.basename($filename);

    copy($source, $destination);

    ?>

    <?php if ($posts) : ?>
    <?php foreach ($posts->getResult() as $post) : ?>
    <?php if ($post->category == 1) { $category = "MEDICAL FRONTLINER";
      } else if ($post->category == 2) { $category = "ESSENTIAL / APOR / GOV'T EMPLOYEE / PUBLIC SERVANT";
      } else if ($post->category == 3) { $category = "BUSINESS PURPOSE";
      } else ($post->category == 3) { $category = "PATIENT & WATCHER" } ?>
    <?php
    $input1 = $post->departure; 
    $input2 = $post->returndate; 
    $today = date('F d, Y'); 
    $date1 = strtotime($input1); 
    $date2 = strtotime($input2); 
    $date_depart = date('F d, Y', $date1); 
    $date_return = date('F d, Y', $date2);
    $date_today = $today;  ?>
    <!-- Modal -->
    <div class="modal fade" id="travelpass" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle"
      aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl" role="document">
        <div class="modal-content w-100 p-3">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalScrollableTitle">Travel Pass</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" id="printThis">
            <div class="col-sm-12 p-3" style="background-color: #fff">
              <div class="row" style="height:150px">
                <div class="col-sm-3 p-2 p-3" style="background-color: #fff">
                  <img src="<?php echo base_url('img/seal_128x128.png'); ?>" class="rounded mx-auto d-block" alt="...">
                </div>
                <div class="col-sm-6 p-2 p-3" style="background-color: #fff">
                  <div class="row">
                    <div class="col-sm-12 text-center" style="background-color: #fff">
                      <h5>Republic of the Philippines</h5>
                      <h5>Bangsamoro Aunomous Region in Muslim Mindanao</h5>
                      <h5>Provincial Government of Basilan</h5>
                    </div>
                  </div>
                  <div class="row"></div>
                  <div class="row">
                    <div class="col-sm-12 text-center" style="background-color: #fff">
                      <h3><b>T R A V E L P A S S</b></h3>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3 p-3" style="background-color: #fff">
                  <div class="col-lg-12 d-flex justify-content-center text-center" style="background-color: #fff">
                    <img src='<?php echo base_url($destination) ?>' alt='qrcode' title='qrcode' width="130"
                      height="130" />
                  </div>
                </div>
              </div>
              <div>&nbsp</div>
              <div>&nbsp</div>
              <div class="row">
                <div class="col-lg-12 col-sm-12 p-2 border border-light" style="background-color: #fff">
                  Travel Pass No. <?php if ($post) { echo $post->pass_id; } ?>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-8 col-sm-8 p-2 border border-light" style="background-color: #e6f2ff">
                  Name ( Lastname, Firstname Middlename )
                </div>
                <div class="col-lg-4 col-sm-4 p-2 border border-light" style="background-color: #e6f2ff">
                  Type of Pass
                </div>
              </div>
              <div class="row">
                <div class="col-lg-8 col-sm-8 p-2 border border-light" style="background-color: #fff">
                  <?php if ($posts_2) : ?>
                  <?php foreach ($posts_2->getResult() as $table) : ?>
                  <h5><?php echo strtoupper($table->lastname.', '.$table->firstname.' '.$table->middlename) ?></h5>
                  <?php endforeach; ?>
                  <?php endif; ?>
                </div>
                <div class="col-lg-4 col-sm-4 p-2 border border-light" style="background-color: #fff">
                  <h5><?php echo $category ?></h5>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Travel to
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Travel Date
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Return to
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Return Date
                </div>
              </div>
              <div class="row">
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #fff">
                  <h5><?php echo $post->citymun.',' ?></h5>
                  <h5><?php echo $prov_name ?></h5>
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light text-center" style="background-color: #fff">
                  <h5><?php echo $date_depart ?></h5>
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light text-center" style="background-color: #fff">
                  <h5>Basilan</h5>
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light text-center" style="background-color: #fff">
                  <h5><?php echo $date_return ?></h5>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-6 col-sm-6 p-2 border border-light" style="background-color: #e6f2ff">
                  Purpose of Travel
                </div>
                <div class="col-lg-6 col-sm-6 p-2 border border-light" style="background-color: #e6f2ff">
                  Attached Documents
                </div>
              </div>
              <div class="row" style="height:150px">
                <div class="col-lg-6 col-sm-6 p-2 border border-light" style="background-color: #fff">
                  <h5><?php if ($post) { echo $post->purpose; } ?></h5>
                </div>
                <div class="col-lg-6 col-sm-6 p-2 border border-light" style="background-color: #fff">
                  <h5><?php echo $doc; ?></h5>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Issued Date
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #fff">
                  <h5><?php echo $date_today ?></h5>
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #e6f2ff">
                  Valid Until
                </div>
                <div class="col-lg-3 col-sm-3 p-2 border border-light" style="background-color: #fff">
                  <h5><?php echo $date_return ?></h5>
                </div>
              </div>
              <div>&nbsp</div>
              <div class="row">
                <div class="col-lg-12 col-sm-12 p-2 border border-light justify-content-center"
                  style="background-color: #fff">
                  <h5>As per emergency purposes indicated to the above mentioned, please allow the bearer to pass. For
                    any
                    inquiries and information, please call PDRRMO / Basilan COVID-19 Task Force Co-Chairman Mr. Nixon
                    Alonzo
                    contact number 0977-668-6702.</h5>
                </div>
              </div>

              <div>&nbsp</div>
              <div>&nbsp</div>
              <div>&nbsp</div>
              <div class="row">
                <div class="col-lg-4 col-sm-4 p-2" style="background-color: #fff">
                  <img src="<?php echo base_url('img/sign1.png'); ?>" alt="..." style="height:150px">
                </div>
                <div class="col-lg-2 col-sm-2 p-2" style="background-color: #fff">
                </div>
                <div class="col-lg-4 col-sm-4 p-2" style="background-color: #fff">
                </div>
                <div class="col-lg-2 col-sm-2 p-2" style="background-color: #fff">
                </div>
              </div>
              <div class="row">
                <div class="col-lg-4 col-sm-4 p-2" style="background-color: #fff">
                  <h5><b>NIXON M. ALONZO</b></h5>
                  <h5>PDRRMO-Basilan</h5>
                  <h5>Task Force - Vice Chairman</h5>
                </div>
                <div class="col-lg-2 col-sm-2 p-2" style="background-color: #fff">
                </div>
                <div class="col-lg-4 col-sm-4 p-2" style="background-color: #fff">
                  <h5><b>HARRYBERT S. HADJALA</b></h5>
                  <h5>Supervising Administrative Officer</h5>
                  <h5>Provincial Health Office-Basilan</h5>
                  <h5>Task Force - Vice Chairman</h5>
                </div>
                <div class="col-lg-2 col-sm-2 p-2" style="background-color: #fff">
                </div>
              </div>

            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" onclick="printDiv('printThis','<?php echo $post->pass_id ?>',)">Print</button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

<script>
    function printDiv(divName, $pass_id) {      
      
      var printContents = document.getElementById(divName).innerHTML;
      var originalContents = document.body.innerHTML;

      document.body.innerHTML = printContents;
      window.print();
      
      window.location.href = "<?php echo base_url() ?>" + '/travelpass/printMe/' + $pass_id;
    }
  </script>

  <script>
    function validate($pass_id) {
      Swal.fire({
        title: 'Are you sure?',
        text: "Validate Requirements!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, validate it!'
      }).then((result) => {
        if (result.value) {

          window.location.href = "<?php echo base_url() ?>" + '/travelpass/validateMe/' + $pass_id;

          Swal.fire({
            title: 'Validated!',
            icon: 'success',
            showCancelButton: false,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ok'
          }).then((result) => {
            if (result.value) {}
          })
        }
      })
    }
  </script>