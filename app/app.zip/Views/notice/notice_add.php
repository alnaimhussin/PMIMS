<style>
  .btnSelect {
    background-color: #f44336;
    border: 2px solid #f44336;
    border-radius: 4px;
    color: white;
    cursor: pointer;
  }

  .btnSelect:hover {
    background-color: #c93326;
    border: 2px solid #c93326;

  }
</style>
<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Add New Notice of Coordination Details</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Add New Notice of Coordination Details</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  <?php 
  $year = date("Y");
  $month = date("m");

  $db = \Config\Database::connect();
  $builder = $db->table('notice');
  $builder->distinct();
  $builder->select('number');
  $builder->like('year', $year);
  $builder->like('month', $month);
  $no = $builder->countAllResults();
  $no = $no + 1;
  
  if ($no > 99) {
    $no2 = $no;
  } else if ($no > 9) {
    $no2 = "0".$no;
  } else {
    $no2 = "00".$no;
  }

  $controlno = $year ."-". $month."-".$no2;

  ?>

  <?php $set = \Config\Services::session()->getFlashdata('validation'); ?>
  <?php $error = \Config\Services::session()->getFlashdata('error'); ?>
  <?php $txt = \Config\Services::validation()->listErrors(); ?>
  <div class="col-lg-6" <?php if ($set != "true") { echo "hidden"; $set = "false"; } ?>>
    <div class="card card-warning">
      <div class="card-header">
        <h3 class="card-title">Fields Required</h3>
      </div>
      <div class="card-body">
        <?php echo $txt; ?>
        <?php echo $error; ?>
      </div>
    </div>
  </div>
  <section class="content">
    <div class="row">
      <div class="col-5">

      </div>
    </div>
    <div class="row col-lg-12">
      <div class="col-lg-5">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">List of all Inbounds</h3>
          </div>
          <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Action</th>
                  <th>Name</th>
                  <th>Documents</th>
                  <th hidden>origin</th>
                  <th hidden>destination</th>
                  <th hidden>lguname</th>
                  <th hidden>departure</th>
                </tr>
              </thead>
              <tbody>
                <?php $i = 1; if ($posts) : ?>
                <?php foreach ($posts->getResult() as $post) : ?>
                <?php if ($post->category == 1) { $category = "LSI"; } else if ($post->category == 2) { $category = "ROF"; } else if ($post->category == 3) { $category = "APOR"; } ?>
                <tr>
                  <td><?php echo $i ?></td>
                  <td><button onclick="addRow(<?php echo $i ?>,<?php echo $year.','.$month.','.$no ?>)">Add</button>
                  </td>
                  <td><?php echo strtoupper($post->lastname.', '.$post->firstname.' '.$post->middlename) ?></td>
                  <td class="<?php if ($post->isValidated != "") { echo "bg-success"; } ?>">
                    <?php if ($post->isValidated != "") { echo "VALIDATED"; } ?></td>
                  <td hidden><?php echo strtoupper($post->citymun.', '.$post->provDesc) ?></td>
                  <td hidden><?php echo strtoupper($post->barangay.', '.$post->lguName) ?></td>
                  <td hidden><?php echo strtoupper($post->lguName) ?></td>
                  <td hidden><?php echo strtoupper($post->departure) ?></td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
              <tfoot>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Notice of Coordination</h3>
          </div>
          <div class="card-body">
            <div class="col-sm-12 col-lg-8">
              <input type="text" class="form-control" id="timestamp" name="timestamp"
                value="<?php echo date("Y-m-d H:i:s"); ?>" placeholder="timestamp" hidden>
            </div>
            <div class="form-group row">
              <label for="controlno" class="col-sm-2 col-lg-2 col-form-label">Control #</label>
              <div class="col-sm-5 col-lg-3">
                <input type="text" class="form-control" id="controlno" name="controlno" placeholder="Control #"
                  value="<?php echo $controlno ?>">
              </div>
            </div>
            <table id="notice_table" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Point of Origin</th>
                  <th>Point of Destination</th>
                  <th>Isolation Facility</th>
                  <th>Expected Travel Date</th>
                  <th hidden>year</th>
                  <th hidden>month</th>
                  <th hidden>day</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
          <div class="card-footer">
            <div class="box-footer">
              <div class="col-lg-3" style="margin-left: auto">
                <button type="button" class="btn btn-success btn-block btn-flat" style="height: 50px; font-size: 20px"
                  onclick="save()">Save</button>
                <button type="button" class="btn btn-primary btn-block btn-flat" style="height: 50px; font-size: 20px"
                  onclick="callPrint()">Print</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<SCRIPT language="javascript">
  var rowCount = 0;

  function validate(id) {
    Swal.fire({
      title: 'Are you sure?',
      text: "Validate Requirements!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, validate it!'
    }).then((result) => {
      if (result.value) {
        $id = id;
        window.location.href = "<?php echo base_url() . '/inbound/validateMe/'; ?>" + id;
        Swal.fire({
          title: 'Validated!',
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ok'
        }).then((result) => {
          if (result.value) {}
        })
      }
    })
  }

  function callSave(year, month, number) {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, save it!'
    }).then((result) => {
      if (result.value) {
        // window.location.href = "<?php echo base_url() . '/notice/save/'; ?>" + year + "/" + month + "/" + number;
        save();
      }
    })
  }

  function callPrint() {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, save it!'
    }).then((result) => {
      if (result.value) {
        // $id = id;
        // window.location.href = "<?php echo base_url() . '/notice/edit/'; ?>" + id;
      }
    })
  }

  function save() {
    var table_data = [];

    $('#notice_table tr').each(function (row, tr) {
      if ($(tr).find('td:eq(0)').text() == "") {

      } else {
        var sub = {
          'name': $(tr).find('td:eq(1)').text(),
          'origin': $(tr).find('td:eq(2)').text(),
          'destination': $(tr).find('td:eq(3)').text(),
          'isolation': $(tr).find('td:eq(4)').text(),
          'departure': $(tr).find('td:eq(5)').text(),
          'year': $(tr).find('td:eq(6)').text(),
          'month': $(tr).find('td:eq(7)').text(),
          'number': $(tr).find('td:eq(8)').text(),
        }
      }      

      $.ajax({
            type: "POST",
            url: "<?php echo base_url().'/notice/save'; ?>",
            data: sub
        })
    });
    
    window.location.href = "<?php echo base_url() . '/notice/add'; ?>";

  }

  function addRow(id, year, month, number) {
    rowCount = rowCount + 1;
    var table = document.getElementById("notice_table");
    var row = table.insertRow(rowCount);
    var n = rowCount.toString();

    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);
    var cell6 = row.insertCell(5);
    var cell7 = row.insertCell(6);
    var cell8 = row.insertCell(7);
    var cell9 = row.insertCell(8);

    $('#notice_table td:nth-child(7)').hide();
    $('#notice_table td:nth-child(8)').hide();
    $('#notice_table td:nth-child(9)').hide();

    cell1.innerHTML = n;
    cell2.innerHTML = $('#example1 tr:eq(' + id + ') td:eq(2)').text();
    cell3.innerHTML = $('#example1 tr:eq(' + id + ') td:eq(4)').text();
    cell4.innerHTML = $('#example1 tr:eq(' + id + ') td:eq(5)').text();
    cell5.innerHTML = $('#example1 tr:eq(' + id + ') td:eq(6)').text();
    cell6.innerHTML = $('#example1 tr:eq(' + id + ') td:eq(7)').text();
    cell7.innerHTML = year;
    cell8.innerHTML = month;
    cell9.innerHTML = number;
  }

  function deleteRow(tableID) {
    try {
      var table = document.getElementById(tableID);
      var rowCount = table.rows.length;

      for (var i = 0; i < rowCount; i++) {
        var row = table.rows[i];
        var chkbox = row.cells[0].childNodes[0];
        if (null != chkbox && true == chkbox.checked) {
          if (rowCount <= 1) {
            alert("Cannot delete all the rows.");
            break;
          }
          table.deleteRow(i);
          rowCount--;
          i--;
        }


      }
    } catch (e) {
      alert(e);
    }
  }
</SCRIPT>