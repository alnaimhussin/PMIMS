<tr>
<td>1</td>
<td>Naim Hussin</td>
<td>Zamboanga City</td>
<td>Lamitan City, Basilan</td>
<td>Lamitan City</td>
<td>12/20/2020</td>
</tr>