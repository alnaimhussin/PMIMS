<?php $session = \Config\Services::session(); ?>

<div class="content-wrapper">
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Employee List</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Employee List</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <?php $set = \Config\Services::session()->getFlashdata('validation'); ?>
  <?php $error = \Config\Services::session()->getFlashdata('error'); ?>
  <?php $txt = \Config\Services::validation()->listErrors(); ?>

  <div class="col-lg-6" <?php if ($set != "true") { echo "hidden"; $set = "false"; } ?>>
    <div class="card card-warning">
      <div class="card-header">
        <h3 class="card-title">Fields Required</h3>
      </div>
      <div class="card-body">
        <?php echo $txt; ?>
        <?php echo $error; ?>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row" style=" margin-bottom: 10px">
        <div class="col-12">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal-add"
            style="width: 200px">Add New Employee</button>
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-lg"
            style="width: 200px">Delete Employee</button>
        </div>
      </div>

      <div class="row" style=" margin-bottom: 10px">
        <div class="col-12">
          <div class="row">
            <div class="col-lg-4">
              <div class="input-group mb-1">
                <div class="input-group-prepend">
                  <span class="input-group-text" style="width: 150px">Department</span>
                </div>
                <select class="form-control select2" id="searchDept" name="searchDept" style="width: 75%;">
                  <option selected="selected" value="0">--</option>
                  <?php if ($department) : ?>
                  <?php foreach ($department->getResult() as $post) : ?>
                  <option value="<?php echo strtoupper($post->dept_code) ?>"><?php echo strtoupper($post->department) ?>
                  </option>
                  <?php endforeach; ?>
                  <?php endif; ?>
                </select>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="input-group mb-1">
                <div class="input-group-prepend">
                  <span class="input-group-text" style="width: 150px">Position</span>
                </div>
                <select class="form-control select2" id="searchPos" name="searchPos" style="width: 75%;">
                  <option selected="selected" value="0">--</option>
                  <?php if ($position) : ?>
                  <?php foreach ($position->getResult() as $post) : ?>
                  <option value="<?php echo strtoupper($post->pos_code) ?>"><?php echo strtoupper($post->position) ?>
                  </option>
                  <?php endforeach; ?>
                  <?php endif; ?>
                </select>
              </div>
            </div>
            <div class="col-lg-1 mt-sm-1 mt-lg-0">
              <button class="btn btn-primary form-control" onclick="search()">Search</button>
            </div>
            <div class="col-lg-1 mt-sm-1 mt-lg-0">
              <button class="btn btn-success form-control" onclick="searchAll()">All</button>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-12">
          <div class="card card-primary card-outline">
            <div class="card-header">
              <h3 class="card-title">Employee List</h3>
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div style="height: auto; padding:15px">
              <div class="card-body table-responsive p-0">
                <table id="employee_table" class="table table-bordered table-head-fixed table-striped table-hover text-nowrap">
                  <thead style="text-align: center">
                    <tr style="line-height: 10px">
                      <th style="width:10%">PGB ID #</th>
                      <th style="width:20%">Fullname</th>
                      <th style="width:5%">Sex</th>
                      <th style="width:10%">Birthday</th>
                      <th>Department</th>
                      <th style="width:15%">Position</th>
                      <th style="width:10%">Salary Grade</th>
                      <th style="width:10%">Status</th>
                    </tr>
                  </thead>
                <tbody id="search" name="search" style="font-size:14px">
                  <?php $n=1; if ($employee) : ?>
                  <?php foreach ($employee->getResult() as $post) : ?>
                  <tr style="line-height: 10px" ondblclick="viewDetail('<?php echo $post->_id; ?>')">
                    <td><?php echo strtoupper($post->pgbid) ?></td>
                    <td><?php echo strtoupper($post->lastname . ', ' . $post->firstname . ' ' . $post->middlename) ?>
                    </td>
                    <td><?php echo strtoupper($post->gender) ?></td>
                    <td><?php echo strtoupper($post->birthdate) ?></td>
                    <td><?php echo strtoupper($post->department) ?></td>
                    <td><?php if ($post->position != "--") {echo strtoupper($post->position . ' ( ' . $post->pos_code . ' )' );} ?></td>
                    <td><?php if ($post->sg_code != "--") {echo strtoupper($post->sg_code);} ?></td>
                    <td><?php echo strtoupper($post->status) ?></td>
                  </tr>
                  <?php $n=$n+1; endforeach; ?>
                  <?php endif; ?>
                </tbody>
                <tfoot style="text-align: center">
                <tr>
                  <th style="width:10%">PGB ID #</th>
                  <th style="width:20%">Fullname</th>
                  <th style="width:5%">Sex</th>
                  <th style="width:10%">Birthday</th>
                  <th>Department</th>
                  <th style="width:15%">Position</th>
                  <th style="width:10%">Salary Grade</th>
                  <th style="width:10%">Status</th>
                </tr>
                </tfoot>
            </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>