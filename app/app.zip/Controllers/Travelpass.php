<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Activitylog_model;
use App\Models\Travelpass_model;
use App\Models\Travelpassmember_model;
use App\Models\Province_model;
use App\Models\Citymun_model;
use App\Models\Lgu_model;

class Travelpass extends BaseController
{
	public function __construct()
	{
	}
	
	public function index()
	{
	}

	public function list()
	{
		$model = new Travelpass_model();
		$data['title']   = ucfirst("travelpass List");
		$data['posts'] = $model->getAll();
		$data['page'] = "travelpass_list";
		$data['pagesub'] = "travelpass_list";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_list');
		echo view('templates/footer', $data);
	}

	public function list_release()
	{
		$model = new Travelpass_model();
		$data['title']   = ucfirst("travelpass List");
		$data['posts'] = $model->getAllRelease();
		$data['page'] = "travelpass";
		$data['pagesub'] = "travelpass_list_release";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_list_release');
		echo view('templates/footer', $data);
	}

	public function add()
	{
		$posts = $this->request->getVar();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$validation =  \Config\Services::validation();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $posts;
		$data['page'] = "data_input";
		$data['pagesub'] = "travelpass_add";

		echo view('templates/header', $data, ['validation' => $validation]);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_add');
		echo view('templates/footer', $data);
	}

	public function addPass()
	{
		$posts = $this->request->getVar();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$validation =  \Config\Services::validation();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $posts;
		$data['page'] = "travelpass";
		$data['pagesub'] = "travelpass_addPass";

		echo view('templates/header', $data, ['validation' => $validation]);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_add_2');
		echo view('templates/footer', $data);
	}

	public function viewMember($pass_id = "")
	{
		$model = new Travelpass_model();
		$model_2 = new Travelpassmember_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($pass_id);
		$data['posts_2'] = $model_2->getDetail($pass_id);
		$data['page'] = "";
		$data['pagesub'] = "";

		$session = \Config\Services::session();
		$model = new Activitylog_model();
		$model->set('timestamp', date('Y-m-d H:i:s'));
		$model->set('access_type', $session->get('access_type'));
		$model->set('access_sub', $session->get('access_sub'));
		$model->set('username', $session->get('username'));
		$model->set('activity', 'viewed');
		$model->set('message', '('.$session->get('username').')'.' Viewed Travel Pass ' . $pass_id);
		$model->insert();

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_viewMember');
		echo view('templates/footer', $data);
	}

	public function edit($id = "")
	{
		$model = new Travelpass_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($id);
		$data['page'] = "travelpass";
		$data['pagesub'] = "travelpass_add";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('travelpass/travelpass_upd');
		echo view('templates/footer', $data);
	}

	public function save()
	{
		$posts = $this->request->getVar();
		$validation =  \Config\Services::validation();
		
		if (!$res) {
			$session = \Config\Services::session();
			$session->setFlashdata('validation', 'true');
			$this->add();
		} else {
			$session = \Config\Services::session();
			try {
				$path = 'public/assets/img/' . date('mdY');
				$directory = FCPATH . $path;
				if ("" != $this->request->getFile('frontlinerid_image')) {
					$newName = $this->request->getFile('frontlinerid_image')->getRandomName();
					$file = $this->request->getFile('frontlinerid_image')->move($directory, $newName);
					$frontlinerid_image = "/" . $path . "/" . $newName;
				} else {
					$frontlinerid_image = "";
				}
				if ("" != $this->request->getFile('governmentid_image')) {
					$newName = $this->request->getFile('governmentid_image')->getRandomName();
					$file = $this->request->getFile('governmentid_image')->move($directory, $newName);
					$governmentid_image = "/" . $path . "/" . $newName;
				} else {
					$governmentid_image = "";
				}
				if ("" != $this->request->getFile('businesspermit_image')) {
					$newName = $this->request->getFile('businesspermit_image')->getRandomName();
					$file = $this->request->getFile('businesspermit_image')->move($directory, $newName);
					$businesspermit_image = "/" . $path . "/" . $newName;
				} else {
					$businesspermit_image = "";
				}
				if ("" != $this->request->getFile('referral_image')) {
					$newName = $this->request->getFile('referral_image')->getRandomName();
					$file = $this->request->getFile('referral_image')->move($directory, $newName);
					$referral_image = "/" . $path . "/" . $newName;
				} else {
					$referral_image = "";
				}
				if ("" != $this->request->getFile('medicalcert_image')) {
					$newName = $this->request->getFile('medicalcert_image')->getRandomName();
					$file = $this->request->getFile('medicalcert_image')->move($directory, $newName);
					$medicalcert_image = "/" . $path . "/" . $newName;
				} else {
					$medicalcert_image = "";
				}
				if ("" != $this->request->getFile('chestxray_image')) {
					$newName = $this->request->getFile('chestxray_image')->getRandomName();
					$file = $this->request->getFile('chestxray_image')->move($directory, $newName);
					$chestxray_image = "/" . $path . "/" . $newName;
				} else {
					$chestxray_image = "";
				}
				if ("" != $this->request->getFile('vehiclepapers_image')) {
					$newName = $this->request->getFile('vehiclepapers_image')->getRandomName();
					$file = $this->request->getFile('vehiclepapers_image')->move($directory, $newName);
					$vehiclepapers_image = "/" . $path . "/" . $newName;
				} else {
					$vehiclepapers_image = "";
				}
				if ("" != $this->request->getFile('travelorder_image')) {
					$newName = $this->request->getFile('travelorder_image')->getRandomName();
					$file = $this->request->getFile('travelorder_image')->move($directory, $newName);
					$travelorder_image = "/" . $path . "/" . $newName;
				} else {
					$travelorder_image = "";
				}

				$model = new Travelpass_model();
				$model->set('frontlinerid_image', $frontlinerid_image);
				$model->set('governmentid_image', $governmentid_image);
				$model->set('referral_image', $referral_image);
				$model->set('businesspermit_image', $businesspermit_image);
				$model->set('medicalcert_image', $medicalcert_image);
				$model->set('chestxray_image', $chestxray_image);
				$model->set('vehiclepapers_image', $vehiclepapers_image);
				$model->set('travelorder_image', $travelorder_image);
				$model->set($posts);
				$model->insert();
				$session->setFlashdata('success', 'New Request Added Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', $e);
			}
			echo $session->getFlashdata('error');
			return redirect()->to(base_url('travelpass/list'));
		}
	}

	public function update($id = "")
	{
		$posts = $this->request->getVar();
		$model = new Travelpass_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			'mobile' => 'required|string',
			'category' => 'required|string',
			'province' => 'required|string',
			'citymun' => 'required|string',
			'lgu' => 'required|string',
			'barangay' => 'required|string',
			'transportation' => 'required|string'
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if (!$res) {
			$this->edit($id);
		} else {
			$session = \Config\Services::session();
			try {
				$model = new Travelpass_model();
				$travelpass = $model->update(['id' => $id], $posts);
				$session->setFlashdata('success', 'travelpass Updated Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', 'Something went wrong.');
			}
			return redirect()->to(base_url('travelpass/list'));
		}
	}

	public function delete($pass_id = "")
	{
		$session = \Config\Services::session();
		try {
			$model = new Travelpass_model();
			$data['travelpass'] = $model->where('id', $id)->delete();

			$model = new Activitylog_model();
			$model->set('timestamp', date('Y-m-d H:i:s'));
			$model->set('access_type', $session->get('access_type'));
			$model->set('access_sub', $session->get('access_sub'));
			$model->set('username', $session->get('username'));
			$model->set('activity', 'deleted');
			$model->set('message', '('.$session->get('username').')'.' Deleted Travel Pass ' . $pass_id);
			$model->insert();

			$session->setFlashdata('success', 'travelpass Deleted Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		return redirect()->to(base_url('travelpass/list'));
	}

	public function validateMe($pass_id = "")
	{
		$session = \Config\Services::session();
		try {
			$db = \Config\Database::connect();
			$builder = $db->table('travelpass');
			$builder->set('status','validated');
			$builder->set('approvedby', $session->get('username'));
			$builder->where('pass_id', $pass_id);
			$builder->update();

			$model = new Activitylog_model();
			$model->set('timestamp', date('Y-m-d H:i:s'));
			$model->set('access_type', $session->get('access_type'));
			$model->set('access_sub', $session->get('access_sub'));
			$model->set('username', $session->get('username'));
			$model->set('activity', 'approved');
			$model->set('message', '('.$session->get('username').')'.' Approved Travel Pass ' . $pass_id);
			$model->insert();

			$session->setFlashdata('success', 'Documents Validated Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		
		return redirect()->to(base_url().'/travelpass/viewMember/'.$pass_id);
	}

	public function printMe($pass_id = "")
	{
		$session = \Config\Services::session();
		try {
			$db = \Config\Database::connect();
			$builder = $db->table('travelpass');
			$builder->set('statusReleased','released');
			$builder->where('pass_id', $pass_id);
			$builder->update();

			$model = new Activitylog_model();
			$model->set('timestamp', date('Y-m-d H:i:s'));
			$model->set('access_type', $session->get('access_type'));
			$model->set('access_sub', $session->get('access_sub'));
			$model->set('username', $session->get('username'));
			$model->set('activity', 'printed');
			$model->set('message', '('.$session->get('username').')'.' Printed Travel Pass ' . $pass_id);
			$model->insert();

		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		
		return redirect()->to(base_url('travelpass/list'));
	}
}