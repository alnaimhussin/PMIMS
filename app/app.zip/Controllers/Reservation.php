<?php

namespace App\Controllers;

class Reservation extends BaseController
{
	public function __construct()
	{
	}
	public function room()
	{
		$data['title']   = ucfirst("Reservation");
		$data['page'] = "reservation";
		$data['pagesub'] = "room";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('reservation/room');		
		echo view('templates/footer', $data);
	}
	public function pool()
	{
		$data['title']   = ucfirst("Reservation");
		$data['page'] = "reservation";
		$data['pagesub'] = "pool";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('reservation/pool');		
		echo view('templates/footer', $data);
	}
	public function list()
	{
	}
}