<?php

namespace App\Controllers;

class Pool extends BaseController
{
	public function __construct()
	{
	}
	public function index()
	{
		$data['title']   = ucfirst("Pool");
		$data['page'] = "pool";
		$data['pagesub'] = "index";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('pool/pool');		
		echo view('templates/footer', $data);
	}
	public function list()
	{
	}
}