<?php

namespace App\Controllers;

use App\Models\Employee_model;
use App\Models\EmployeeID_model;
use App\Models\Employee_details_model;
use App\Models\Employee_contacts_model;
use App\Models\Employee_education_model;
use App\Models\Employee_eligibility_model;
use App\Models\Employee_membership_model;
use App\Models\Master_salarygrade_model;
use App\Models\Master_province_model;
use App\Models\Master_citymunicipal_model;
use App\Models\Master_department_model;
use App\Models\Master_position_model;
use App\Models\Master_profession_model;

class Employee extends BaseController
{
	public function __construct()
	{
	}
	public function index()
	{
		$model1 = new Employee_model();
		$model2 = new Master_department_model();
		$model3 = new Master_position_model();
		$model4 = new Master_profession_model();
		$model5 = new Master_salarygrade_model();
		$model6 = new Master_province_model();
		$model7 = new Master_citymunicipal_model();
		$data['title'] = ucfirst("Employee List"); // Capitalize the first letter
		$data['employee'] = $model1->getAll();
		$data['department'] = $model2->getAll();
		$data['position'] = $model3->getAll();
		$data['profession'] = $model4->getAll();
		$data['salarygrade'] = $model5->getAll();
		$data['province'] = $model6->getAll();
		$data['citymunicipal'] = $model7->getAll();
		$data['page'] = "employee-list";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('employee/employee', $data);	
		echo view('employee/employee_add', $data);	
		echo view('employee/employee_view', $data);	
		// echo view('employee/employee_update', $data);
		echo view('employee/employee_function', $data);	
		echo view('employee/employee_script', $data);		
		echo view('templates/footer');
	}
	public function id()
	{
		$model1 = new EmployeeID_model();
		$model2 = new Master_department_model();
		$model3 = new Master_position_model();
		$data['title'] = ucfirst("Employee ID List"); // Capitalize the first letter
		$data['emp_id'] = $model1->getAll();
		$data['department'] = $model2->getAll();
		$data['position'] = $model3->getAll();
		$data['page'] = "employeeid";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('employee/employeeid', $data);	
		echo view('templates/footer');
	}
	
	public function checkDuplicateID()
	{
		$pgbid = $this->request->getVar('pgbid');

		$model1 = new Employee_model();
		$count = $model1->checkDuplicateID($pgbid);
		echo json_encode($count);
	}

	public function checkDuplicateName()
	{
		$lastname = $this->request->getVar('lastname');
		$firstname = $this->request->getVar('firstname');
		$middlename = $this->request->getVar('middlename');

		$model1 = new Employee_model();
		$count = $model1->checkDuplicateName($lastname,$firstname,$middlename);
		echo json_encode($count);
	}

	public function checkDuplicateName_view()
	{
		$lastname = $this->request->getVar('v_lastname');
		$firstname = $this->request->getVar('v_firstname');
		$middlename = $this->request->getVar('v_middlename');

		$model1 = new Employee_model();
		$count = $model1->checkDuplicateName($lastname,$firstname,$middlename);
		echo json_encode($count);
	}

	public function add()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		$validation = \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			'initial' => 'required|string',
		]);
		$res = $validation->withRequest($this->request)->run();
		if (!$res) {
			$session->setFlashdata('validation', 'true');
			$this->index();
		} else {
			try {
				$model1 = new Employee_model();
				$model2 = new Employee_membership_model();
				$model3 = new Employee_details_model();
				$model4 = new Employee_contacts_model();
				$model1->set($posts);
				$model1->insert();
				$id = $model1->getInsertID();

				$model2->set('id_', $id);
				$model2->set('gsis', $this->request->getVar('gsis'));
				$model2->set('philhealth', $this->request->getVar('philhealth'));
				$model2->set('pagibig', $this->request->getVar('pagibig'));
				$model2->set('sss', $this->request->getVar('sss'));
				$model2->set('tin', $this->request->getVar('tin'));
				$model2->insert();
				
				$model3->set('id_', $id);
				$model3->set('sg_code', $this->request->getVar('sg_code'));
				$model3->set('dept_code', $this->request->getVar('dept_code'));
				$model3->set('pos_code', $this->request->getVar('pos_code'));
				$model3->set('status', $this->request->getVar('status'));
				$model3->insert();
				
				$model4->set('id_', $id);
				$model4->set('e_lastname', $this->request->getVar('e_lastname'));
				$model4->set('e_firstname', $this->request->getVar('e_firstname'));
				$model4->set('e_middlename', $this->request->getVar('e_middlename'));
				$model4->set('e_relation', $this->request->getVar('e_relation'));
				$model4->set('e_extname', $this->request->getVar('e_extname'));
				$model4->set('e_contact', $this->request->getVar('e_contact'));
				$model4->set('r_lot', $this->request->getVar('r_lot'));
				$model4->set('r_street', $this->request->getVar('r_street'));
				$model4->set('r_village', $this->request->getVar('r_village'));
				$model4->set('r_barangay', $this->request->getVar('r_barangay'));
				$model4->set('r_citymunicipal', $this->request->getVar('r_citymunicipal'));
				$model4->set('r_province', $this->request->getVar('r_province'));
				$model4->set('p_lot', $this->request->getVar('p_lot'));
				$model4->set('p_street', $this->request->getVar('p_street'));
				$model4->set('p_village', $this->request->getVar('p_village'));
				$model4->set('p_barangay', $this->request->getVar('p_barangay'));
				$model4->set('p_citymunicipal', $this->request->getVar('p_citymunicipal'));
				$model4->set('p_province', $this->request->getVar('p_province'));
				$model4->insert();

				$session->setFlashdata('success', "Successfully Added New Employee");
			} catch (\Exception $e) {
				$session->setFlashdata('error', $e);
			}

			echo json_encode($id);
		}
	}

	public function update()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		$validation = \Config\Services::validation();
		$validation->setRules([
			'v_lastname' => 'required|string',
			'v_firstname' => 'required|string',
			'v_middlename' => 'required|string',
			'v_initial' => 'required|string',
		]);
		$res = $validation->withRequest($this->request)->run();
		if (!$res) {
			$session->setFlashdata('validation', 'true');
			$this->index();
		} else {
			try {
				$id = $this->request->getVar('v_id');

				$model1 = new Employee_model();
				$model2 = new Employee_membership_model();
				$model3 = new Employee_details_model();
				$model4 = new Employee_contacts_model();
				$model1->set('lastname', $this->request->getVar('v_lastname'));
				$model1->set('firstname', $this->request->getVar('v_firstname'));
				$model1->set('middlename', $this->request->getVar('v_middlename'));
				$model1->set('initial', $this->request->getVar('v_initial'));
				$model1->set('nickname', $this->request->getVar('v_nickname'));
				$model1->set('prof_code', $this->request->getVar('v_prof_code'));
				$model1->set('pgbid', $this->request->getVar('v_pgbid'));
				$model1->set('exname', $this->request->getVar('v_exname'));
				$model1->set('height', $this->request->getVar('v_height'));
				$model1->set('weight', $this->request->getVar('v_weight'));
				$model1->set('birthdate', $this->request->getVar('v_birthdate'));
				$model1->set('birthplace', $this->request->getVar('v_birthplace'));
				$model1->set('gender', $this->request->getVar('v_gender'));
				$model1->set('civilstatus', $this->request->getVar('v_civilstatus'));
				$model1->set('bloodtype', $this->request->getVar('v_bloodtype'));
				$model1->set('gender', $this->request->getVar('v_gender'));
				$model1->set('email', $this->request->getVar('v_email'));
				$model1->set('contact', $this->request->getVar('v_contact'));
				$model1->where('id',$id);
				$model1->update();

				$model2->set('id_', $id);
				$model2->set('gsis', $this->request->getVar('v_gsis'));
				$model2->set('philhealth', $this->request->getVar('v_philhealth'));
				$model2->set('pagibig', $this->request->getVar('v_pagibig'));
				$model2->set('sss', $this->request->getVar('v_sss'));
				$model2->set('tin', $this->request->getVar('v_tin'));
				$model2->where('id_',$id);
				$model2->update();
				
				$model3->set('id_', $id);
				$model3->set('sg_code', $this->request->getVar('v_sg_code'));
				$model3->set('dept_code', $this->request->getVar('v_dept_code'));
				$model3->set('pos_code', $this->request->getVar('v_pos_code'));
				$model3->set('status', $this->request->getVar('v_status'));
				$model3->where('id_',$id);
				$model3->update();
				
				$model4->set('id_', $id);
				$model4->set('e_lastname', $this->request->getVar('v_e_lastname'));
				$model4->set('e_firstname', $this->request->getVar('v_e_firstname'));
				$model4->set('e_middlename', $this->request->getVar('v_e_middlename'));
				$model4->set('e_relation', $this->request->getVar('v_e_relation'));
				$model4->set('e_extname', $this->request->getVar('v_e_extname'));
				$model4->set('e_contact', $this->request->getVar('v_e_contact'));
				$model4->set('r_lot', $this->request->getVar('v_r_lot'));
				$model4->set('r_street', $this->request->getVar('v_r_street'));
				$model4->set('r_village', $this->request->getVar('v_r_village'));
				$model4->set('r_barangay', $this->request->getVar('v_r_barangay'));
				$model4->set('r_citymunicipal', $this->request->getVar('v_r_citymunicipal'));
				$model4->set('r_province', $this->request->getVar('v_r_province'));
				$model4->set('p_lot', $this->request->getVar('v_p_lot'));
				$model4->set('p_street', $this->request->getVar('v_p_street'));
				$model4->set('p_village', $this->request->getVar('v_p_village'));
				$model4->set('p_barangay', $this->request->getVar('v_p_barangay'));
				$model4->set('p_citymunicipal', $this->request->getVar('v_p_citymunicipal'));
				$model4->set('p_province', $this->request->getVar('v_p_province'));
				$model4->where('id_',$id);
				$model4->update();

				$session->setFlashdata('success', "Successfully Updated Employee");

			} catch (\Exception $e) {
				$session->setFlashdata('error', $e);
			}	

			echo $id;		
		}
	}

	public function addEducation()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_education_model();
			$model1->set($posts);
			$model1->insert();			
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}

		echo json_encode($status);
	}

	public function updateEducation()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_education_model();

			$model1->set($posts);
			$model1->insert();		
			
			$status = "success";	
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}
	}

	public function deleteEducation()
	{
		$id = $this->request->getVar('tempID');

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_education_model();
			$model1->where('id_', $id);
			$model1->delete();		
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}
	}

	public function addEligibility()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_eligibility_model();
			$model1->set($posts);
			$model1->insert();			
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}

		echo json_encode($status);
	}

	public function updateEligibility()
	{
		$posts = $this->request->getVar();

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_eligibility_model();

			$model1->set($posts);
			$model1->insert();		

			$status = "updated eligibility";	
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}

		echo json_encode($status);
	}

	public function deleteEligibility()
	{
		$id = $this->request->getVar('tempID');

		$session = \Config\Services::session();
		try {
			$model1 = new Employee_eligibility_model();
			$model1->where('id_', $id);
			$model1->delete();	

			$status = "deleted eligibility";	
		} catch (\Exception $e) {
			$status = $e;
			$session->setFlashdata('error', $e);
		}
		echo json_encode($status);
	}

	

	public function save()
	{
		$posts = $this->request->getVar();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'file_picture' => [
				'rules' => 'is_image[file_picture]|max_size[file_picture,2048]'
			],
			'file_signature' => [
				'rules' => 'is_image[file_signature]|max_size[file_signature,2048]'
			],
			'file_qrcode' => [
				'rules' => 'is_image[file_qrcode]|max_size[file_qrcode,2048]'
			],
		]);
		$res = $validation->withRequest($this->request)->run();
		if (!$res) {
			$session = \Config\Services::session();
			$session->setFlashdata('validation', 'true');
			$this->id();
		} else {
			$session = \Config\Services::session();
			try {
				$path = 'public/assets/img/' . $this->request->getVar('dept_code');
				$directory = FCPATH . $path;
				if ("" != $this->request->getFile('file_picture')) {
					$newName = $this->request->getVar('lastname').$this->request->getVar('firstname').'-picture.png';
					$file = $this->request->getFile('file_picture')->move($directory, $newName);
					$file_picture = "/" . $path . "/" . $newName;
				} else {
					$file_picture = "";
				}
				if ("" != $this->request->getFile('file_signature')) {
					$newName = $this->request->getVar('lastname').$this->request->getVar('firstname').'-signature.png';
					$file = $this->request->getFile('file_signature')->move($directory, $newName);
					$file_signature = "/" . $path . "/" . $newName;
				} else {
					$file_signature = "";
				}
				if ("" != $this->request->getFile('file_qrcode')) {
					$newName = $this->request->getVar('lastname').$this->request->getVar('firstname').'-qrcode.png';
					$file = $this->request->getFile('file_qrcode')->move($directory, $newName);
					$file_qrcode = "/" . $path . "/" . $newName;
				} else {
					$file_qrcode = "";
				}

				$model = new EmployeeID_model();
				$model->set('pgbid', $this->request->getVar('pgbid2'));
				$model->set('unique_id',$this->request->getVar('unique_id'));
				$model->set('file_picture', $file_picture);
				$model->set('file_signature', $file_signature);
				$model->set('file_qrcode', $file_qrcode); 
				$model->insert();
				$session->setFlashdata('success', 'New ID Added Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', $e);
			}
			echo $session->getFlashdata('error');
			return redirect()->to(base_url('employee/id'));
		}
	}
}