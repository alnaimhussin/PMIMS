<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\Auth_model;
 
class Register extends Controller
{
    public function index()
    {
        //include helper form
        helper(['form']);
        $data = [];
        echo view('register', $data);
    }
 
    public function save()
    {
        //include helper form
        helper(['form']);
        //set rules validation form
        $rules = [
            'username'          => 'required|min_length[3]|max_length[20]',
            'firstname'          => 'required|min_length[3]|max_length[20]',
            'lastname'         => 'required|min_length[3]|max_length[20]',
            'password'      => 'required|min_length[6]|max_length[200]',
            'confpassword'  => 'matches[password]'
        ];
         
        if($this->validate($rules)){
            $model = new Auth_model();
            $data = [
                'access_type'     => $this->request->getVar('access_type'),
                'access_sub'     => $this->request->getVar('access_sub'),
                'firstname'     => $this->request->getVar('firstname'),
                'lastname'     => $this->request->getVar('lastname'),                
                'username'     => $this->request->getVar('username'),
                'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
            ];
            $model->save($data);
            return redirect()->to(base_url('/users/list'));
        }
         
    }
 
}