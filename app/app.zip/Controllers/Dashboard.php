<?php namespace App\Controllers;
 
use CodeIgniter\Controller;

use App\Models\Employee_model;
use App\Models\Master_department_model;
 
class Dashboard extends Controller
{
    public function index()
    {
		$model1 = new Employee_model();
		$model2 = new Master_department_model();
		$data['title'] = ucfirst("Dashb0oard");
		$data['countAll'] = $model1->getCount();
		$data['countMale'] = $model1->getMale();
		$data['countFemale'] = $model1->getFemale();
		$data['department'] = $model2->getAll();
		$data['alldept'] = $model1->getCountByDept();
		$data['permanent'] = $model1->getCountPermanent();
		$data['casual'] = $model1->getCountCasual();
		$data['joborder'] = $model1->getCountJobOrder();
		$data['page'] = "dashboard";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('dashboard/dashboard', $data);
		echo view('templates/footer', $data);
    }
}