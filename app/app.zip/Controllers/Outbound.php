<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Province_model;
use App\Models\Outbound_model;
use App\Models\Citymun_model;
use App\Models\Lgu_model;

class Outbound extends BaseController
{
	public function __construct()
	{
	}
	public function index()
	{
	}

	public function list()
	{
		$model = new Outbound_model();
		$data['title']   = ucfirst("Outbound List");
		$data['posts'] = $model->getAll();
		$data['page'] = "outbound";
		$data['pagesub'] = "outbound_list";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('outbound/outbound_list');
		echo view('templates/footer', $data);
	}

	public function add()
	{
		$posts = $this->request->getVar();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$validation =  \Config\Services::validation();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $posts;
		$data['page'] = "data_input";
		$data['pagesub'] = "outbound_add";

		echo view('templates/header', $data, ['validation' => $validation]);
		echo view('menu/sidebar', $data);
		echo view('outbound/outbound_add');
		echo view('templates/footer', $data);
	}

	public function view($id = "")
	{
		$model = new Outbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($id);
		$data['page'] = "inbound";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('outbound/outbound_view');
		echo view('templates/footer', $data);
	}

	public function edit($id = "")
	{
		$model = new Outbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($id);
		$data['page'] = "outbound";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('outbound/outbound_upd');
		echo view('templates/footer', $data);
	}

	public function save()
	{
		$data = $this->request->getVar();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			// 'firstname' => 'required|integer|greater_than[0]',
			// 'email' => 'required|valid_email'
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if (!$res) {

			$data['title']   = ucfirst("Add New Outbound");
			$data['poweredby'] = ucfirst("CodeIgniter"); // Capitalize the first letter
			$data['page'] = "outbound";
			$data['pagesub'] = "outbound_add";

			echo view('templates/header', $data, ['validation' => $validation]);
			echo view('menu/sidebar', $data);
			echo view('outbound/outbound_add');
			echo view('templates/footer', $data);
		} else {
			$session = \Config\Services::session();
			try {
				$model = new Outbound_model();
				$Outbound = $model->insert($data);
				$session->setFlashdata('success', 'outbound Added Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', 'Something went wrong.');
			}
			return redirect()->to(base_url('outbound/addGovtID'));
		}
	}

	public function update($id = "")
	{
		$posts = $this->request->getVar();
		$model = new Outbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			'mobile' => 'required|string',
			'category' => 'required|string',
			'province' => 'required|string',
			'citymun' => 'required|string',
			'lgu' => 'required|string',
			'barangay' => 'required|string',
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if (!$res) {
			$this->edit($id);
		} else {
			$session = \Config\Services::session();
			try {
				$model = new Outbound_model();
				$inbound = $model->update(['id' => $id], $posts);
				$session->setFlashdata('success', 'Outbound Updated Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', 'Something went wrong.');
			}
			return redirect()->to(base_url('outbound/list'));
		}
	}
	
	public function delete($id = null)
	{

		$session = \Config\Services::session();
		try {
			$model = new Outbound_model();
			$data['outbound'] = $model->where('id', $id)->delete();
			$session->setFlashdata('success', 'outbound Deleted Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		return redirect()->to(base_url('outbound/list'));
	}

	public function validateMe($id = "")
	{
		$session = \Config\Services::session();
		try {
			$db = \Config\Database::connect();
			$builder = $db->table('outbound');
			$builder->set('isValidated','validated');
			$builder->where('id', $id);
			$builder->update();
			$session->setFlashdata('success', 'Documents Validated Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		return redirect()->to(base_url('outbound/list'));
	}
	//--------------------------------------------------------------------
}