<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Inbound_model;
use App\Models\Outbound_model;
use App\Models\Travelpass_model;

class Admin extends BaseController
{
	public function index()
	{
		$model = new Inbound_model();
		$model2 = new Outbound_model();
		$model3 = new Travelpass_model();
		$data['posts'] = $model->getLGUTotal();
		$data['arrival'] = $model->countArrival();
		$data['inbound'] = $model->countInbound();
		$data['outbound'] = $model2->countOutbound();
		// $data['travelpass'] = $model3->countTravelpass();	
		$data['page'] = "admin";
		$data['pagesub'] = "admin";

		echo view('templates/header', $data);
		echo view('menu/sidebar');
		echo view('home/dashboard');
		echo view('templates/footer');
	}

	function login()
	{
		echo view('login/login');
	}

	//--------------------------------------------------------------------

}
