<?php

namespace App\Controllers;

class Events extends BaseController
{
	public function __construct()
	{
	}
	public function index()
	{
		$data['title']   = ucfirst("Events");
		$data['page'] = "events";
		$data['pagesub'] = "index";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('events/events');		
		echo view('templates/footer', $data);
	}
	public function list()
	{
	}
}