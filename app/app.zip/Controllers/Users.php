<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Users_model;

class Users extends BaseController
{
	public function __construct()
	{
	}
	
	public function index()
	{
	}

	public function list()
	{
		$model = new Users_model();
		$data['title']   = ucfirst("User List");
		$data['posts'] = $model->getAll();
		$data['page'] = "user_list";
		$data['pagesub'] = "user_list";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('user/user_list');
		echo view('templates/footer', $data);
	}

}