<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\Auth_model;
 
class Login extends Controller
{
    public function index()
    {
        helper(['form']);
        echo view(base_url('/login'));
    } 
 
    public function auth()
    {
        $session = session();
        $model = new Auth_model();
        $access_type = $this->request->getVar('access_type');
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');
        $data = $model->where('username', $username)->first();
     
        if($data){
        
            $pass = $data['password'];
            $accesstype = $data['access_type'];

            if($access_type == $accesstype) {           
                $verify_pass = password_verify($password, $pass);
                if($verify_pass){
                    $ses_data = [
                        'id'            => $data['id'],
                        'access_type'   => $data['access_type'],
                        'access_sub'    => $data['access_sub'],
                        'lastname'      => $data['lastname'],
                        'firstname'     => $data['firstname'],
                        'username'      => $data['username'],
                        'logged_in'     => TRUE
                    ];
                    $session->set($ses_data);
                    return redirect()->to(base_url('/admin'));
                }else{
                    $session->setFlashdata('msg', 'Wrong Password');
                    return redirect()->to(base_url('/admin/login'));
                }    
            } else {
                $session->setFlashdata('msg', 'Invalid Credentials');
                return redirect()->to(base_url('/admin/login'));
            }
        }else{
            $session->setFlashdata('msg', 'Username not Found');
            return redirect()->to(base_url('/admin/login'));
        }
    }
 
    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to(base_url('/admin/login'));
    }
} 