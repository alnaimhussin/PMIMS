<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Employee_model;
use App\Models\Master_position_model;
use App\Models\Master_profession_model;

class Dynamic extends BaseController
{
 
 public function __construct()
 {
 }

 function search_pgbid($pgbid)
 {
    $model = new Employee_model();
    $data = $model->searchEmployee($pgbid)->getResult();
    echo json_encode($data);
 }

 function search_name($lastname,$firstname)
 {
    $model = new Employee_model();
    $data = $model->searchEmployeeName($lastname,$firstname)->getResult();
    echo json_encode($data);
 }

 function refreshPos() {
   $model = new Master_position_model();
   $data = $model->getAll()->getResult();
   echo json_encode($data);
 }

 function refreshProf() {
   $model = new Master_profession_model();
   $data = $model->getAll()->getResult();
   echo json_encode($data);
 }
 
 function searchByDeptPos($dept_code, $pos_code)
 {
    $model = new Employee_model();
    $data = $model->searchByDeptPos($dept_code, $pos_code)->getResult();
    echo json_encode($data);
 }

 function searchByDept($dept_code)
 {
    $model = new Employee_model();
    $data = $model->searchByDept($dept_code)->getResult();
    echo json_encode($data);
 }
 
 function searchByPos($pos_code)
 {
    $model = new Employee_model();
    $data = $model->searchByPos($pos_code)->getResult();
    echo json_encode($data);
 }
 
 function searchAll()
 {
    $model = new Employee_model();
    $data = $model->searchAll()->getResult();
    echo json_encode($data);
 }

 function getDetail($id)
 {
    $model = new Employee_model();
    $data = $model->getDetail($id)->getResult();
    echo json_encode($data);
 }

 function viewDetail($id)
 {
    $model = new Employee_model();
    $data = $model->viewDetail($id)->getResult();
    echo json_encode($data);
 }

 function viewDetailEducation($id)
 {
    $model = new Employee_model();
    $data = $model->viewDetailEducation($id)->getResult();
    echo json_encode($data);
 }

 function viewDetailEligibility($id)
 {
    $model = new Employee_model();
    $data = $model->viewDetailEligibility($id)->getResult();
    echo json_encode($data);
 }
 
  
}
