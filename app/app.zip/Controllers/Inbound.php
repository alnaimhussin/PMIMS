<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Inbound_model;
use App\Models\Province_model;
use App\Models\Citymun_model;
use App\Models\Lgu_model;

class Inbound extends BaseController
{
	public function __construct()
	{
	}
	public function index()
	{
	}

	public function list()
	{
		$model = new Inbound_model();
		$data['title'] = ucfirst("Inbound List");
		$data['posts'] = $model->getAll();
		$data['page'] = "inbound";
		$data['pagesub'] = "inbound_list";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('inbound/inbound_list');
		echo view('templates/footer', $data);
	}

	public function add()
	{
		$posts = $this->request->getVar();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$validation =  \Config\Services::validation();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $posts;
		$data['page'] = "data_input";
		$data['pagesub'] = "inbound_add";

		echo view('templates/header', $data, ['validation' => $validation]);
		echo view('menu/sidebar', $data);
		echo view('inbound/inbound_add');
		echo view('templates/footer', $data);
	}

	public function view($id = "")
	{
		$model = new Inbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($id);
		$data['page'] = "inbound";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('inbound/inbound_view');
		echo view('templates/footer', $data);
	}

	public function edit($id = "")
	{
		$model = new Inbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$data['posts'] = $model->getDetail($id);
		$data['page'] = "inbound";
		$data['pagesub'] = "";

		echo view('templates/header', $data);
		echo view('menu/sidebar', $data);
		echo view('inbound/inbound_upd');
		echo view('templates/footer', $data);
	}

	public function save()
	{
		$posts = $this->request->getVar();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			'mobile' => 'required|string',
			'category' => 'required|string',
			'province' => 'required|string',
			'citymun' => 'required|string',
			'lgu' => 'required|string',
			'barangay' => 'required|string',
			'transportation' => 'required|string',
			'medicalcert_image' => [
				'rules' => 'is_image[medicalcert_image]|max_size[medicalcert_image,2048]',
				'label' => 'Medical Certificate'
			],
			'travelauth_image' => [
				'rules' => 'is_image[travelauth_image]|max_size[travelauth_image,2048]',
				'label' => 'Travel Authority'
			],
			'residency_image' => [
				'rules' => 'is_image[residency_image]|max_size[residency_image,2048]',
				'label' => 'Prrof of Residency'
			],
			'owwa_image' => [
				'rules' => 'is_image[owwa_image]|max_size[owwa_image,2048]',
				'label' => 'OWWA Coordination'
			],
			'companyid_image' => [
				'rules' => 'is_image[companyid_image]|max_size[companyid_image,2048]',
				'label' => 'Company ID'
			],
			'employmentcert_image' => [
				'rules' => 'is_image[employmentcert_image]|max_size[employmentcert_image,2048]',
				'label' => 'Employment Certificate'
			],
			'travelorder_image' => [
				'rules' => 'is_image[travelorder_image]|max_size[travelorder_image,2048]',
				'label' => 'Travel Order'
			],
		]);
		$res = $validation->withRequest($this->request)->run();
		if (!$res) {
			$session = \Config\Services::session();
			$session->setFlashdata('validation', 'true');
			$this->add();
		} else {
			$session = \Config\Services::session();
			try {
				$path = 'public/assets/img/' . date('mdY');
				$directory = FCPATH . $path;
				if ("" != $this->request->getFile('medicalcert_image')) {
					$newName = $this->request->getFile('medicalcert_image')->getRandomName();
					$file = $this->request->getFile('medicalcert_image')->move($directory, $newName);
					$medicalcert_image = "/" . $path . "/" . $newName;
				} else {
					$medicalcert_image = "";
				}
				if ("" != $this->request->getFile('travelauth_image')) {
					$newName = $this->request->getFile('travelauth_image')->getRandomName();
					$file = $this->request->getFile('travelauth_image')->move($directory, $newName);
					$travelauth_image = "/" . $path . "/" . $newName;
				} else {
					$travelauth_image = "";
				}
				if ("" != $this->request->getFile('residency_image')) {
					$newName = $this->request->getFile('residency_image')->getRandomName();
					$file = $this->request->getFile('residency_image')->move($directory, $newName);
					$residency_image = "/" . $path . "/" . $newName;
				} else {
					$residency_image = "";
				}
				if ("" != $this->request->getFile('owwa_image')) {
					$newName = $this->request->getFile('owwa_image')->getRandomName();
					$file = $this->request->getFile('owwa_image')->move($directory, $newName);
					$owwa_image = "/" . $path . "/" . $newName;
				} else {
					$owwa_image = "";
				}
				if ("" != $this->request->getFile('companyid_image')) {
					$newName = $this->request->getFile('companyid_image')->getRandomName();
					$file = $this->request->getFile('companyid_image')->move($directory, $newName);
					$companyid_image = "/" . $path . "/" . $newName;
				} else {
					$companyid_image = "";
				}
				if ("" != $this->request->getFile('employmentcert_image')) {
					$newName = $this->request->getFile('employmentcert_image')->getRandomName();
					$file = $this->request->getFile('employmentcert_image')->move($directory, $newName);
					$employmentcert_image = "/" . $path . "/" . $newName;
				} else {
					$employmentcert_image = "";
				}
				if ("" != $this->request->getFile('travelorder_image')) {
					$newName = $this->request->getFile('travelorder_image')->getRandomName();
					$file = $this->request->getFile('travelorder_image')->move($directory, $newName);
					$travelorder_image = "/" . $path . "/" . $newName;
				} else {
					$travelorder_image = "";
				}

				$model = new Inbound_model();
				$model->set('medicalcert_image', $medicalcert_image);
				$model->set('travelauth_image', $travelauth_image);
				$model->set('residency_image', $residency_image);
				$model->set('owwa_image', $owwa_image);
				$model->set('companyid_image', $companyid_image);
				$model->set('employmentcert_image', $employmentcert_image);
				$model->set('travelorder_image', $travelorder_image);
				$model->set($posts);
				$model->insert();
				$session->setFlashdata('success', 'Inbound Added Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', $e);
			}
			echo $session->getFlashdata('error');
			return redirect()->to(base_url('inbound/list'));
		}
	}

	public function update($id = "")
	{
		$posts = $this->request->getVar();
		$model = new Inbound_model();
		$province = new Province_model();
		$citymun = new Citymun_model();
		$lgu = new Lgu_model();
		$data['province'] = $province->getProvinceSort();
		$data['citymun'] = $citymun->findAll();
		$data['lgu'] = $lgu->getLguSort();
		$validation =  \Config\Services::validation();
		$validation->setRules([
			'lastname' => 'required|string',
			'firstname' => 'required|string',
			'middlename' => 'required|string',
			'mobile' => 'required|string',
			'category' => 'required|string',
			'province' => 'required|string',
			'citymun' => 'required|string',
			'lgu' => 'required|string',
			'barangay' => 'required|string',
			'transportation' => 'required|string'
		]);
		$res = $validation->withRequest($this->request)
			->run();
		if (!$res) {
			$this->edit($id);
		} else {
			$session = \Config\Services::session();
			try {
				$model = new Inbound_model();
				$inbound = $model->update(['id' => $id], $posts);
				$session->setFlashdata('success', 'Inbound Updated Successfully.');
			} catch (\Exception $e) {
				$session->setFlashdata('error', 'Something went wrong.');
			}
			return redirect()->to(base_url('inbound/list'));
		}
	}

	public function delete($id = "")
	{
		$session = \Config\Services::session();
		try {
			$model = new Inbound_model();
			$data['inbound'] = $model->where('id', $id)->delete();
			$session->setFlashdata('success', 'Inbound Deleted Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		return redirect()->to(base_url('inbound/list'));
	}

	public function validateMe($id = "")
	{
		$session = \Config\Services::session();
		try {
			$db = \Config\Database::connect();
			$builder = $db->table('inbound');
			$builder->set('isValidated','validated');
			$builder->where('id', $id);
			$builder->update();
			$session->setFlashdata('success', 'Documents Validated Successfully.');
		} catch (\Exception $e) {
			$session->setFlashdata('error', 'Something went wrong.');
		}
		return redirect()->to(base_url('inbound/list'));
	}

	//--------------------------------------------------------------------

}