<?php namespace App\Models;

use CodeIgniter\Model;

class Master_position_model extends Model
{
    
    protected $table = 'pgb_position';
    protected $primaryKey = 'id';
	protected $allowedFields = ['position','description','pos_code'];

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_position');
        $builder->select('position,description,pos_code');
        $builder->orderBy('position','ASC');
        return $builder->get();
    }

}