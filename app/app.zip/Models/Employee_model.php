<?php namespace App\Models;

use CodeIgniter\Model;

class Employee_model extends Model
{
    protected $table = 'pgb_employee';
    protected $primaryKey = 'id';
	protected $allowedFields = ['lastname','firstname','middlename','initial','nickname','birthdate','birthplace','gender','civilstatus',
    'prof_code','exname','bloodtype','height','weight','bloodtype','email','contact','pgbid'];

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->orderBy('lastname', 'ASC');
        return $builder->get();
    }
    
    public function getLastID()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->selectMax('id');
        return $builder->get();
    }
    
    public function getCount()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('id');
        return $builder->countAll();
    }    

    public function getCountByDept()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee_details');
        $builder->select('dept_code, count(dept_code) as allcount');
        $builder->groupby('dept_code');
        $builder->orderBy('dept_code','ASC');
        return $builder->get();
    }    

    public function getCountPermanent()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee_details');
        $builder->select('dept_code, count(dept_code) as permanent');
        $builder->where('status', 'Permanent');
        $builder->groupby('dept_code');
        $builder->orderBy('dept_code','ASC');
        return $builder->get();
    }
    
    public function getCountCasual()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee_details');
        $builder->select('dept_code, count(dept_code) as casual');
        $builder->where('status', 'Casual');
        $builder->groupby('dept_code');
        $builder->orderBy('dept_code','ASC');
        return $builder->get();
    }
    
    public function getCountJobOrder()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee_details');
        $builder->select('dept_code, count(dept_code) as joborder');
        $builder->where('status', 'JO');
        $builder->groupby('dept_code');
        $builder->orderBy('dept_code','ASC');
        return $builder->get();
    }
    
    public function getMale()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('id');
        $builder->where('gender', 'Male');
        return $builder->countAllResults();
    }
    
    public function getFemale()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('id');
        $builder->where('gender', 'Female');
        return $builder->countAllResults();
    }

    public function searchEmployee($pgbid)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->where('pgbid', $pgbid);
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function searchEmployeeName($lastname,$firstname)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->like('lastname', $lastname, 'both');
        $builder->like('firstname', $firstname, 'both');
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function searchByDeptPos($dept_code, $pos_code)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->like('pgb_employee_details.dept_code', $dept_code, 'both');
        $builder->like('pgb_employee_details.pos_code', $pos_code, 'both');
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function searchByDept($dept_code)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->where('pgb_employee_details.dept_code', $dept_code);
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function searchByPos($pos_code)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->where('pgb_employee_details.pos_code', $pos_code);
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function searchAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->orderBy('lastname', 'ASC');
        $data = $builder->get();
        return $data;
    }

    public function viewDetail($id) 
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_employee_contacts', 'pgb_employee.id = pgb_employee_contacts.id_');
        $builder->join('pgb_employee_membership', 'pgb_employee.id = pgb_employee_membership.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->where('pgb_employee.id', $id);
        $data = $builder->get();
        return $data;
    }

    public function viewDetailEducation($id) 
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_employee_education', 'pgb_employee.id = pgb_employee_education.id_');
        $builder->where('pgb_employee.id', $id);
        $data = $builder->get();
        return $data;
    }

    public function viewDetailEligibility($id) 
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_employee_eligibility', 'pgb_employee.id = pgb_employee_eligibility.id_');
        $builder->where('pgb_employee.id', $id);
        $data = $builder->get();
        return $data;
    }

    public function getDetail($id) 
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('*,pgb_employee.id as _id');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_employee_contacts', 'pgb_employee.id = pgb_employee_contacts.id_');
        $builder->join('pgb_employee_membership', 'pgb_employee.id = pgb_employee_membership.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->join('pgb_position', 'pgb_employee_details.pos_code = pgb_position.pos_code');
        $builder->where('pgb_employee.id', $id);
        $data = $builder->get();
        return $data;
    }
    
    public function checkDuplicateID($pgbid)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('pgbid');
        $builder->where('pgbid', $pgbid);
        return $builder->countAllResults();
    }
    
    public function checkDuplicateName($lastname,$firstname,$middlename)
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_employee');
        $builder->select('pgbid');
        $builder->where('lastname', $lastname, 'both');
        $builder->where('firstname', $firstname, 'both');
        $builder->where('middlename', $middlename, 'both');
        return $builder->countAllResults();
    }

}