<?php namespace App\Models;

use CodeIgniter\Model;

class EmployeeID_model extends Model
{
    protected $table = 'pgb_emp_id';
    protected $primaryKey = 'id';
	protected $allowedFields = ['pgbid','unique_id','file_picture','file_signature','file_qrcode'];

    protected $useTimestamps = false;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

    public function __construct()
    {
        parent::__construct();
    }

    public function getAll()
    {
        $db = \Config\Database::connect();
        $builder = $db->table('pgb_emp_id');
        $builder->select('*');
        $builder->join('pgb_employee', 'pgb_emp_id.pgbid = pgb_employee.pgbid');
        $builder->join('pgb_employee_details', 'pgb_employee.id = pgb_employee_details.id_');
        $builder->join('pgb_department', 'pgb_employee_details.dept_code = pgb_department.dept_code');
        $builder->orderBy('lastname', 'ASC');
        return $builder->get();
    }

}